/*
 * FuzzyClassifyNetworkTraffic.java
 *
 * Created on Oct 07th 2022
 *
 * Based on Juzzy by Christian Wagner
 */

package example;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;
import java.util.TreeMap;

import generic.Input;
import generic.Output;
import generic.Tuple;
import intervalType2.sets.IntervalT2MF_Interface;
import intervalType2.sets.IntervalT2MF_Trapezoidal;
import intervalType2.sets.IntervalT2MF_Triangular;
import intervalType2.system.IT2_Antecedent;
import intervalType2.system.IT2_Consequent;
import intervalType2.system.IT2_Rule;
import intervalType2.system.IT2_Rulebase;
import tools.JMathPlotter;
import type1.sets.T1MF_Trapezoidal;
import type1.sets.T1MF_Triangular;

/**
 * A simple example of a type-2 FLS based on the "Classify Network".
 * 
 * @author Bruno Moura
 */
public class FuzzyClassifyNetworkTrafic {
	
	// the inputs to the FLS
	Input normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd, normFlowIATMean,
	normFlowIATStd, normFwdIATMean, normFwdIATStd, normBwdIATMean, normPacketLengthMean, normPacketLengthStd;
	
	// the output of the FLS
	Output video; 
	// the rulebase captures the entire FLS
	IT2_Rulebase rulebase; 
	
	String linguisticClassification;
	int accuracy;
	int accuracyCount = 0;
	
	private Double OutputXValue;
    private Double OutputYValue;
    
    private boolean degreeInput = false;

	public FuzzyClassifyNetworkTrafic() throws IOException {

		System.out.println("Starting system...");
		
		// Define the inputs
		normFwdPacketLengthMean = new Input("NormFwd_Packet_Length_Mean degree", new Tuple(0, 10));
		normFwdPacketLengthStd = new Input("NormFwd_PacketLengthStd degree", new Tuple(0, 10));
		normBwdPacketLengthMean = new Input("NormBwd_Packet_Length_Mean degree", new Tuple(0, 10));
		normBwdPacketLengthStd = new Input("NormBwd_Packet_Length_Std degree", new Tuple(0, 10));
		normFlowIATMean = new Input("NormFlow_IAT_Mean degree", new Tuple(0, 10));
		normFlowIATStd = new Input("NormFlow_IAT_Std degree", new Tuple(0, 10));
		normFwdIATMean = new Input("NormFwd_IAT_Mean degree", new Tuple(0, 10));
		normFwdIATStd = new Input("NormFwd_IAT_Std degree", new Tuple(0, 10));
		normBwdIATMean = new Input("NormBwd_IAT_Mean degree", new Tuple(0, 10));
		normPacketLengthMean  = new Input("NormPacket_Length_Mean degree", new Tuple(0, 10));
		normPacketLengthStd  = new Input("NormPacket_Length_Std degree", new Tuple(0, 10));
		
		//normBwdIATMean essa faltou
		
		
		// Define the output
		video = new Output("Video classification", new Tuple(0, 10));
		
		/*
		double startUpperVeryLowLimit = -7.5;   
		double peakUpperVeryLowLimit =  0;   
		double endUpperVeryLowLimit =  7.5;   
		
		double startLowerVeryLowLimit = -5.0; 
		double peakLowerVeryLowLimit =  0; 
		double endLowerVeryLowLimit =   5.0;
		*/
		
		//String n, double start, double peak, double end
		
		//Very Low
		double startUpperVeryLowLimit = -1.5;   
		double peakUpperVeryLowLimit =  0;   
		double endUpperVeryLowLimit =  1.5;   
		
		double startLowerVeryLowLimit = -0.5; 
		double peakLowerVeryLowLimit =  0; 
		double endLowerVeryLowLimit =   0.5;
		
				
		// Low
		double startUpperLowLimit = -0;   
		double peakUpperLowLimit =  1;   
		double endUpperLowLimit =  2.5;   
		
		double startLowerLowLimit = 0.8; 
		double peakLowerLowLimit =  1; 
		double endLowerLowLimit =   1.8;
		
		
		// Bellow Reasonable
		double startUpperBellowReasonableLimit = 0.5;   
		double peakUpperBellowReasonableLimit =  3.8;   
		double endUpperBellowReasonableLimit =  7.2;   
		
		double startLowerBellowReasonableLimit = 1.8; 
		double peakLowerBellowReasonableLimit =  3.8; 
		double endLowerBellowReasonableLimit =   6;

		
        
	    // Reasonable	
		double startUpperReasonableLimit = 3.4; 
		double peakUpperReasonableLimit =  6.8; 
		double endUpperReasonableLimit =   9.8; 
		
		double startLowerReasonableLimit = 4.5; 
		double peakLowerReasonableLimit =  6.8; 
		double endLowerReasonableLimit =  8.5; 

		
		//High
		double startUpperHighLimit = 6.2; 
		double peakUpperHighLimit = 10; 
		double endUpperHighLimit =  12.2; 
		
		double startLowerHighLimit = 7.2; 
		double peakLowerHighLimit = 10; 
		double endLowerHighLimit = 11.2; 
		
		// Video output

		// Low
		double startUpperLowLimitVideo = -2;   
		double peakUpperLowLimitVideo =  0;   
		double endUpperLowLimitVideo =  4.5;   
		
		double startLowerLowLimitVideo = -1; 
		double peakLowerLowLimitVideo =  0; 
		double endLowerLowLimitVideo =   3.5;
		
		//Average
		double startUpperAverageLimitVideo = 2.5; 
		double peakUpperAverageLimitVideo =  5.0; 
		double endUpperAverageLimitVideo =   8.5; 
		
		double startLowerAverageLimitVideo = 3.5; 
		double peakLowerAverageLimitVideo =  5.0; 
		double endLowerAverageLimitVideo =  7.5; 
		
		
		
		
		//High
		double startUpperHighLimitVideo = 4.5; 
		double peakUpperHighLimitVideo =  10; 
		double endUpperHighLimitVideo =   12; 
		
		double startLowerHighLimitVideo = 5.5; 
		double peakLowerHighLimitVideo =  10; 
		double endLowerHighLimitVideo =  11;
       
		


		// Set up the membership functions (MFs) for each input and output

		
		
		// NormFwd_Packet_Length_Mean input
		
		T1MF_Triangular upperVeryLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper VeryLow NormFwd_Packet_Length_Mean", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower VeryLow NormFwd_Packet_Length_Mean", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for VeryLow NormFwd_Packet_Length_Mean", upperVeryLowNormFwdPacketLengthMeanMF, lowerVeryLowNormFwdPacketLengthMeanMF);

		
		T1MF_Triangular upperLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Low NormFwd_Packet_Length_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower Low NormFwd_Packet_Length_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormFwd_Packet_Length_Mean", upperLowNormFwdPacketLengthMeanMF, lowerLowNormFwdPacketLengthMeanMF);

		
		T1MF_Triangular  upperBelowReasonableNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFwd_Packet_Length_Mean", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFwd_Packet_Length_Mean", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormFwd_Packet_Length_Mean", upperBelowReasonableNormFwdPacketLengthMeanMF, lowerBellowReasonableNormFwdPacketLengthMeanMF);

		
		T1MF_Triangular  upperReasonableNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Reasonable NormFwd_Packet_Length_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormFwd_Packet_Length_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFwd_Packet_Length_Mean", upperReasonableNormFwdPacketLengthMeanMF, lowerReasonableNormFwdPacketLengthMeanMF);

		
		
		T1MF_Triangular upperHighNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper High NormFwd_Packet_Length_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower High NormFwd_Packet_Length_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFwd_Packet_Length_Mean", upperHighNormFwdPacketLengthMeanMF, lowerHighNormFwdPacketLengthMeanMF);
		

		
		// NormFwd_Packet_Length_Std input
		T1MF_Triangular upperVeryLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Very Low NormFwd_Packet_Length_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for lower Very Low NormFwd_Packet_Length_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFwd_Packet_Length_Std", upperVeryLowNormFwdPacketLengthStdMF, lowerVeryLowNormFwdPacketLengthStdMF);
		
		T1MF_Triangular upperLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Low NormFwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for lower Low NormFwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormFwd_Packet_Length_Std", upperLowNormFwdPacketLengthStdMF, lowerLowNormFwdPacketLengthStdMF);
		
		T1MF_Triangular  upperBellowReasonableNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFwd_Packet_Length_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFwd_Packet_Length_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormFwd_Packet_Length_Std", upperBellowReasonableNormFwdPacketLengthStdMF, lowerBellowReasonableNormFwdPacketLengthStdMF);


		
		T1MF_Triangular  upperReasonableNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Reasonable NormFwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower Reasonable NormFwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFwd_Packet_Length_Std", upperReasonableNormFwdPacketLengthStdMF, lowerReasonableNormFwdPacketLengthStdMF);

		
		T1MF_Triangular upperHighNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper High NormFwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for lower High NormFwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFwd_Packet_Length_Std", upperHighNormFwdPacketLengthStdMF, lowerHighNormFwdPacketLengthStdMF);

		
		//NormBwd_Packet_Length_Mean input
		T1MF_Triangular upperVeryLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Very Low NormFwd_Packet_Length_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower Very Low NormFwd_Packet_Length_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_Packet_Length_Std", upperVeryLowNormBwdPacketLengthMeanMF, lowerVeryLowNormBwdPacketLengthMeanMF);

		
		T1MF_Triangular upperLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Low NormFwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower Low NormFwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormFwd_Packet_Length_Std", upperLowNormBwdPacketLengthMeanMF, lowerLowNormBwdPacketLengthMeanMF);

		
		
		T1MF_Triangular  upperBellowReasonableNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFwd_Packet_Length_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormBwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFwd_Packet_Length_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormFwd_Packet_Length_Std", upperBellowReasonableNormBwdPacketLengthMeanMF, lowerBellowReasonableNormBwdPacketLengthMeanMF);
		
		T1MF_Triangular  upperReasonableNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper Reasonable NormFwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormFwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFwd_Packet_Length_Std", upperReasonableNormBwdPacketLengthMeanMF, lowerReasonableNormBwdPacketLengthMeanMF);

		
		T1MF_Triangular upperHighNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper High NormFwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower High NormFwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFwd_Packet_Length_Std", upperHighNormBwdPacketLengthMeanMF, lowerHighNormBwdPacketLengthMeanMF);

		
		//NormBwd_Packet_Length_Std input
		T1MF_Triangular upperVeryLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Very Low NormBwd_Packet_Length_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for lower Very Low NormBwd_Packet_Length_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormBwd_Packet_Length_Std", upperVeryLowNormBwdPacketLengthStdMF, lowerVeryLowNormBwdPacketLengthStdMF);

		
		T1MF_Triangular upperLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Low NormBwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for lower Low NormBwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormBwd_Packet_Length_Std", upperLowNormBwdPacketLengthStdMF, lowerLowNormBwdPacketLengthStdMF);
		
		T1MF_Triangular  upperBellowReasonableNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormBwd_Packet_Length_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormBwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormBwd_Packet_Length_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormBwd_Packet_Length_Std", upperBellowReasonableNormBwdPacketLengthStdMF, lowerBellowReasonableNormBwdPacketLengthStdMF);


		T1MF_Triangular  upperReasonableNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper reasonable NormBwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower reasonable NormBwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormBwd_Packet_Length_Std", upperReasonableNormBwdPacketLengthStdMF, lowerReasonableNormBwdPacketLengthStdMF);

		T1MF_Triangular upperHighNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper high NormBwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for lower high NormBwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormBwd_Packet_Length_Std", upperHighNormBwdPacketLengthStdMF, lowerHighNormBwdPacketLengthStdMF);

		

		//NormFlow_IAT_Mean input NormFlowIATMean
		T1MF_Triangular upperVeryLowNormFlowIATMeanMF = new T1MF_Triangular("MF for upper Very Low NormFlow_IAT_Mean", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFlowIATMeanMF = new T1MF_Triangular("MF for lower Very Low NormFlow_IAT_Mean", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFlow_IAT_Mean", upperVeryLowNormFlowIATMeanMF, lowerVeryLowNormFlowIATMeanMF);
		

		T1MF_Triangular upperLowNormFlowIATMeanMF = new T1MF_Triangular("MF for upper Low NormFlow_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFlowIATMeanMF = new T1MF_Triangular("MF for lower Low NormFlow_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormFlow_IAT_Mean", upperLowNormFlowIATMeanMF, lowerLowNormFlowIATMeanMF);
		
		T1MF_Triangular  upperBellowReasonableNormFlowIATMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFlow_IAT_Mean", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFlowIATMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFlow_IAT_Mean", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFlow_IAT_Mean", upperBellowReasonableNormFlowIATMeanMF, lowerBellowReasonableNormFlowIATMeanMF);

		
		T1MF_Triangular  upperReasonableNormFlowIATMeanMF = new T1MF_Triangular("MF for upper Reasonable NormFlow_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFlowIATMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormFlow_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFlow_IAT_Mean", upperReasonableNormFlowIATMeanMF, lowerReasonableNormFlowIATMeanMF);

		T1MF_Triangular upperHighNormFlowIATMeanMF = new T1MF_Triangular("MF for upper High NormFlow_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFlowIATMeanMF = new T1MF_Triangular("MF for lower High NormFlow_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFlow_IAT_Mean", upperHighNormFlowIATMeanMF, lowerHighNormFlowIATMeanMF);

		//NormFlow_IAT_Std input NormFlowIATStd
		T1MF_Triangular upperVeryLowNormFlowIATStdMF = new T1MF_Triangular("MF for upper Very Low NormFlow_IAT_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFlowIATStdMF = new T1MF_Triangular("MF for lower Very Low NormFlow_IAT_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFlow_IAT_Std", upperVeryLowNormFlowIATStdMF, lowerVeryLowNormFlowIATStdMF);
		
		T1MF_Triangular upperLowNormFlowIATStdMF = new T1MF_Triangular("MF for upper Low NormFlow_IAT_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFlowIATStdMF = new T1MF_Triangular("MF for lower Low NormFlow_IAT_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormFlow_IAT_Std", upperLowNormFlowIATStdMF, lowerLowNormFlowIATStdMF);
		
		
		T1MF_Triangular  upperBellowReasonableNormFlowIATStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFlow_IAT_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFlowIATStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFlow_IAT_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormFlow_IAT_Std", upperBellowReasonableNormFlowIATStdMF, lowerBellowReasonableNormFlowIATStdMF);


		T1MF_Triangular  upperReasonableNormFlowIATStdMF = new T1MF_Triangular("MF for upper Reasonable NormFlow_IAT_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFlowIATStdMF  = new T1MF_Triangular("MF for lower Reasonable NormFlow_IAT_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFlow_IAT_Std", upperReasonableNormFlowIATStdMF, lowerReasonableNormFlowIATStdMF);

		T1MF_Triangular upperHighNormFlowIATStdMF = new T1MF_Triangular("MF for upper High NormFlow_IAT_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFlowIATStdMF = new T1MF_Triangular("MF for lower High NormFlow_IAT_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFlow_IAT_Std", upperHighNormFlowIATStdMF, lowerHighNormFlowIATStdMF);

       		
		//NormFwd_IAT_Mean input NormFwdIATMean
		
		T1MF_Triangular upperVeryLowNormFwdIATMeanMF = new T1MF_Triangular("MF for upper Very Low NormFwd_IAT_Mean", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFwdIATMeanMF = new T1MF_Triangular("MF for lower Very Low NormFwd_IAT_Mean", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFwd_IAT_Mean", upperVeryLowNormFwdIATMeanMF, lowerVeryLowNormFwdIATMeanMF);
		
		T1MF_Triangular upperLowNormFwdIATMeanMF = new T1MF_Triangular("MF for upper low NormFwd_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdIATMeanMF = new T1MF_Triangular("MF for lower low NormFwd_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_IAT_Mean", upperLowNormFwdIATMeanMF, lowerLowNormFwdIATMeanMF);
		
		T1MF_Triangular  upperBellowReasonableNormFwdIATMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFwd_IAT_Mean", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFwdIATMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFwd_IAT_Mean", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Bllow Reasonable NormFwd_IAT_Mean", upperBellowReasonableNormFwdIATMeanMF, lowerBellowReasonableNormFwdIATMeanMF);

		T1MF_Triangular  upperReasonableNormFwdIATMeanMF = new T1MF_Triangular("MF for upper Reasonable NormFwd_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdIATMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormFwd_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFwd_IAT_Mean", upperReasonableNormFwdIATMeanMF, lowerReasonableNormFwdIATMeanMF);

		T1MF_Triangular upperHighNormFwdIATMeanMF = new T1MF_Triangular("MF for upper high NormFwd_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdIATMeanMF = new T1MF_Triangular("MF for lower high NormFwd_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_IAT_Mean", upperHighNormFwdIATMeanMF, lowerHighNormFwdIATMeanMF);
		
		
		
		// NormFwd_IAT_Std input
		T1MF_Triangular upperVeryLowNormFwdIATStdMF = new T1MF_Triangular("MF for upper Very Low NormFwd_IAT_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormFwdIATStdMF = new T1MF_Triangular("MF for lower Very Low NormFwd_IAT_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFwd_IAT_Std", upperVeryLowNormFwdIATStdMF, lowerVeryLowNormFwdIATStdMF);

		
		T1MF_Triangular upperLowNormFwdIATStdMF = new T1MF_Triangular("MF for upper Very Low NormFwd_IAT_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdIATStdMF = new T1MF_Triangular("MF for lower Very Low NormFwd_IAT_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormFwd_IAT_Std", upperLowNormFwdIATStdMF, lowerLowNormFwdIATStdMF);
		
		T1MF_Triangular  upperBellowReasonableNormFwdIATStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormFwd_IAT_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormFwdIATStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormFwd_IAT_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormFwd_IAT_Std", upperBellowReasonableNormFwdIATStdMF, lowerBellowReasonableNormFwdIATStdMF);

		T1MF_Triangular  upperReasonableNormFwdIATStdMF = new T1MF_Triangular("MF for upper Reasonable NormFwd_IAT_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdIATStdMF  = new T1MF_Triangular("MF for lower Reasonable NormFwd_IAT_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormFwd_IAT_Std", upperReasonableNormFwdIATStdMF, lowerReasonableNormFwdIATStdMF);

		T1MF_Triangular upperHighNormFwdIATStdMF = new T1MF_Triangular("MF for upper High NormFwd_IAT_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdIATStdMF = new T1MF_Triangular("MF for lower High NormFwd_IAT_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for High NormFwd_IAT_Std", upperHighNormFwdIATStdMF, lowerHighNormFwdIATStdMF);

		
		
		// NormBwd_IAT_Mean input
		T1MF_Triangular upperVeryLowNormBwdIATMeanMF = new T1MF_Triangular("MF for upper Very Low NormBwd_IAT_Mean", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormBwdIATMeanMF = new T1MF_Triangular("MF for lower Very Low NormBwd_IAT_Mean", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormBwd_IAT_Mean", upperVeryLowNormBwdIATMeanMF, lowerVeryLowNormBwdIATMeanMF);

		T1MF_Triangular upperLowNormBwdIATMeanMF = new T1MF_Triangular("MF for upper Low NormBwd_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdIATMeanMF = new T1MF_Triangular("MF for lower low NormBwd_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormBwd_IAT_Mean", upperLowNormBwdIATMeanMF, lowerLowNormBwdIATMeanMF);
		
		T1MF_Triangular  upperBellowReasonableNormBwdIATMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormBwd_IAT_Mean", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormBwdIATMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormBwd_IAT_Mean", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormBwd_IAT_Mean", upperBellowReasonableNormBwdIATMeanMF, lowerBellowReasonableNormBwdIATMeanMF);

		T1MF_Triangular  upperReasonableNormBwdIATMeanMF = new T1MF_Triangular("MF for upper Reasonable NormBwd_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdIATMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormBwd_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormBwd_IAT_Mean", upperReasonableNormBwdIATMeanMF, lowerReasonableNormBwdIATMeanMF);

		T1MF_Triangular upperHighNormBwdIATMeanMF = new T1MF_Triangular("MF for upper High NormBwd_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdIATMeanMF = new T1MF_Triangular("MF for lower High NormBwd_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for High NormBwd_IAT_Mean", upperHighNormBwdIATMeanMF, lowerHighNormBwdIATMeanMF);

		
		//NormPacket_Length_Mean input
		T1MF_Triangular upperVeryLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper Very Low NormPacket_Length_Mean", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for lower Very Low NormPacket_Length_Mean", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormPacket_Length_Mean", upperVeryLowNormPacketLengthMeanMF, lowerVeryLowNormPacketLengthMeanMF);

		
		T1MF_Triangular upperLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper Low NormPacket_Length_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for lower Low NormPacket_Length_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormPacket_Length_Mean", upperLowNormPacketLengthMeanMF, lowerLowNormPacketLengthMeanMF);
		
		T1MF_Triangular  upperBellowReasonableNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormPacket_Length_Mean", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormPacket_Length_Mean", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormPacket_Length_Mean", upperBellowReasonableNormPacketLengthMeanMF, lowerBellowReasonableNormPacketLengthMeanMF);

		T1MF_Triangular  upperReasonableNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper Reasonable NormPacket_Length_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormPacketLengthMeanMF  = new T1MF_Triangular("MF for lower Reasonable NormPacket_Length_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormPacket_Length_Mean", upperReasonableNormPacketLengthMeanMF, lowerReasonableNormPacketLengthMeanMF);

		T1MF_Triangular upperHighNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper High NormPacket_Length_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormPacketLengthMeanMF = new T1MF_Triangular("MF for lower High NormPacket_Length_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormPacket_Length_Mean", upperHighNormPacketLengthMeanMF, lowerHighNormPacketLengthMeanMF);
		
		
		// NormPacket_Length_Std input
		T1MF_Triangular upperVeryLowNormPacketLengthStdMF = new T1MF_Triangular("MF for upper Very Low NormPacket_Length_Std", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		T1MF_Triangular lowerVeryLowNormPacketLengthStdMF = new T1MF_Triangular("MF for lower Very Low NormPacket_Length_Std", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		IntervalT2MF_Triangular veryLowNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low NormPacket_Length_Std", upperVeryLowNormPacketLengthStdMF, lowerVeryLowNormPacketLengthStdMF);

		
		T1MF_Triangular upperLowNormPacketLengthStdMF = new T1MF_Triangular("MF for upper Low NormPacket_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormPacketLengthStdMF = new T1MF_Triangular("MF for lower Low NormPacket_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Low NormPacket_Length_Std", upperLowNormPacketLengthStdMF, lowerLowNormPacketLengthStdMF);
		
        // verificar este termo linguistico
		/*
		T1MF_Triangular  upperBellowReasonableNormPacketLengthStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormPacket_Length_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormPacketLengthStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormPacket_Length_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormPacket_Length_Std", upperBellowReasonableNormPacketLengthStdMF, lowerBellowReasonableNormPacketLengthStdMF);
        */
		
		T1MF_Triangular  upperBellowReasonableNormPacketLengthStdMF = new T1MF_Triangular("MF for upper Bellow Reasonable NormPacket_Length_Std", startUpperBellowReasonableLimit, peakUpperBellowReasonableLimit, endUpperBellowReasonableLimit);
		T1MF_Triangular lowerBellowReasonableNormPacketLengthStdMF  = new T1MF_Triangular("MF for lower Bellow Reasonable NormPacket_Length_Std", startLowerBellowReasonableLimit, peakLowerBellowReasonableLimit, endLowerBellowReasonableLimit);
		IntervalT2MF_Triangular bellowReasonableNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Bellow Reasonable NormPacket_Length_Std", upperBellowReasonableNormPacketLengthStdMF, lowerBellowReasonableNormPacketLengthStdMF);
		
		T1MF_Triangular  upperReasonableNormPacketLengthStdMF = new T1MF_Triangular("MF for upper Reasonable NormPacket_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormPacketLengthStdMF  = new T1MF_Triangular("MF for lower Reasonable NormPacket_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for Reasonable NormPacket_Length_Std", upperReasonableNormPacketLengthStdMF, lowerReasonableNormPacketLengthStdMF);

		T1MF_Triangular upperHighNormPacketLengthStdMF = new T1MF_Triangular("MF for upper High NormPacket_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormPacketLengthStdMF = new T1MF_Triangular("MF for lower High NormPacket_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for High NormPacket_Length_Std", upperHighNormPacketLengthStdMF, lowerHighNormPacketLengthStdMF);


		
		// Video output
		
		//T1MF_Triangular upperVeryLowVideoMF = new T1MF_Triangular("MF for upper Very Low video", startUpperVeryLowLimit, peakUpperVeryLowLimit, endUpperVeryLowLimit);
		//T1MF_Triangular lowerVeryLowVideoMF = new T1MF_Triangular("MF for lower Very Low video", startLowerVeryLowLimit, peakLowerVeryLowLimit, endLowerVeryLowLimit);
		//IntervalT2MF_Triangular veryLowVideoT2MF = new IntervalT2MF_Triangular("T2 MF for Very Low video", upperVeryLowVideoMF, lowerVeryLowVideoMF);

		
		T1MF_Triangular upperLowVideoMF = new T1MF_Triangular("MF for upper Low video", startUpperLowLimitVideo, peakUpperLowLimitVideo, endUpperLowLimitVideo);
		T1MF_Triangular lowerLowVideoMF = new T1MF_Triangular("MF for lower Low video", startLowerLowLimitVideo, peakLowerLowLimitVideo, endLowerLowLimitVideo);
		IntervalT2MF_Triangular lowVideoT2MF = new IntervalT2MF_Triangular("T2 MF for Low video", upperLowVideoMF, lowerLowVideoMF);
		

		T1MF_Triangular  upperAverageVideoMF = new T1MF_Triangular("MF for upper Average video", startUpperAverageLimitVideo, peakUpperAverageLimitVideo, endUpperAverageLimitVideo);
		T1MF_Triangular lowerAverageVideoMF  = new T1MF_Triangular("MF for lower Average video", startLowerAverageLimitVideo, peakLowerAverageLimitVideo, endLowerAverageLimitVideo);
		IntervalT2MF_Triangular averageVideoT2MF = new IntervalT2MF_Triangular("T2 MF for Average video", upperAverageVideoMF, lowerAverageVideoMF);

		T1MF_Triangular upperHighVideoMF = new T1MF_Triangular("MF for upper High video", startUpperHighLimitVideo, peakUpperHighLimitVideo, endUpperHighLimitVideo);
		T1MF_Triangular lowerHighVideoMF = new T1MF_Triangular("MF for lower High video", startLowerHighLimitVideo, peakLowerHighLimitVideo, endUpperHighLimitVideo);
		IntervalT2MF_Triangular  highVideoT2MF = new IntervalT2MF_Triangular("T2 MF for High video", upperHighNormFwdPacketLengthStdMF, lowerHighNormFwdPacketLengthStdMF);
 
		
		

		System.out.println("Membership functions setted...");
		
		// Set up the antecedents and consequents - note how the inputs are associated...

		// NormFwd_Packet_Length_Mean
		IT2_Antecedent veryLowNormFwd_Packet_Length_Mean = new IT2_Antecedent("Very Low NormFwd_Packet_Length_Mean", veryLowNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent lowNormFwd_Packet_Length_Mean = new IT2_Antecedent("Low NormFwd_Packet_Length_Mean", lowNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent bellowReasonableNormFwd_Packet_Length_Mean = new IT2_Antecedent("Bellow Reasonable NormFwd_Packet_Length_Mean", bellowReasonableNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent reasonableNormFwd_Packet_Length_Mean = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Mean", reasonableNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent highNormFwd_Packet_Length_Mean = new IT2_Antecedent("High NormFwd_Packet_Length_Mean", highNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		
		
		
		// NormFwd_Packet_Length_Std antecedent
		 IT2_Antecedent veryLowNormFwd_Packet_Length_Std = new IT2_Antecedent("Very Low NormFwd_Packet_Length_Std", veryLowNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent lowNormFwd_Packet_Length_Std = new IT2_Antecedent("Low NormFwd_Packet_Length_Std", lowNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent bellowReasonableNormFwd_Packet_Length_Std = new IT2_Antecedent("Bellow Reasonable NormFwd_Packet_Length_Std", bellowReasonableNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent reasonableNormFwd_Packet_Length_Std = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Std", reasonableNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent highNormFwd_Packet_Length_Std = new IT2_Antecedent("High NormFwd_Packet_Length_Std", highNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		
		
		// NormBwd_Packet_Length_Mean antecedent
		 IT2_Antecedent veryLowNormBwd_Packet_Length_Mean = new IT2_Antecedent("Very Low NormFwd_Packet_Length_Std", veryLowNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent lowNormBwd_Packet_Length_Mean = new IT2_Antecedent("Low NormFwd_Packet_Length_Std", lowNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent bellowReasonableNormBwd_Packet_Length_Mean = new IT2_Antecedent("Bellow Reasonable NormFwd_Packet_Length_Std", bellowReasonableNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent reasonableNormBwd_Packet_Length_Mean = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Std", reasonableNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent highNormBwd_Packet_Length_Mean = new IT2_Antecedent("High NormFwd_Packet_Length_Std", highNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 
		 
		 
		// NormBwd_Packet_Length_Std  antecedent
		 IT2_Antecedent veryLowNormBwd_Packet_Length_Std = new IT2_Antecedent("Very Low NormBwd_Packet_Length_Std ", veryLowNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent lowNormBwd_Packet_Length_Std = new IT2_Antecedent("Low NormBwd_Packet_Length_Std ", lowNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent bellowReasonableNormBwd_Packet_Length_Std = new IT2_Antecedent("Bellow Reasonable NormBwd_Packet_Length_Std ", bellowReasonableNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent reasonableNormBwd_Packet_Length_Std = new IT2_Antecedent("Reasonable NormBwd_Packet_Length_Std ", reasonableNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent highNormBwd_Packet_Length_Std = new IT2_Antecedent("High NormBwd_Packet_Length_Std ", highNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		
		 
		
		// NormFlow_IAT_Mean antecedent
		 IT2_Antecedent veryLowNormFlow_IAT_Mean = new IT2_Antecedent("Very Low NormFlow_IAT_Mean ", veryLowNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent lowNormFlow_IAT_Mean = new IT2_Antecedent("Low NormFlow_IAT_Mean ", lowNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent bellowReasonableNormFlow_IAT_Mean = new IT2_Antecedent("Bellow Reasonable NormFlow_IAT_Mean ", bellowReasonableNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent reasonableNormFlow_IAT_Mean = new IT2_Antecedent("Reasonable NormFlow_IAT_Mean ", reasonableNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent highNormFlow_IAT_Mean = new IT2_Antecedent("High NormFlow_IAT_Mean ", highNormFlowIATMeanT2MF, normFlowIATMean);
		
		 
		 
		// NormFlow_IAT_Std antecedent 
		 IT2_Antecedent veryLowNormFlow_IAT_Std = new IT2_Antecedent("Very Low NormFlow_IAT_Std ", veryLowNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent lowNormFlow_IAT_Std = new IT2_Antecedent("Low NormFlow_IAT_Std ", lowNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent bellowReasonableNormFlow_IAT_Std = new IT2_Antecedent("Bellow Reasonable NormFlow_IAT_Std ", bellowReasonableNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent reasonableNormFlow_IAT_Std = new IT2_Antecedent("Reasonable NormFlow_IAT_Std ", reasonableNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent highNormFlow_IAT_Std = new IT2_Antecedent("High NormFlow_IAT_Std ", highNormFlowIATStdT2MF, normFlowIATStd);

		 
		 
        // NormFwd_IAT_Mean input antecedent
		 IT2_Antecedent veryLowNormFwd_IAT_Mean = new IT2_Antecedent("Very Low NormFwd_IAT_Mean ", veryLowNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent lowNormFwd_IAT_Mean = new IT2_Antecedent("Low NormFwd_IAT_Mean ", lowNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent bellowReasonableNormFwd_IAT_Mean = new IT2_Antecedent("Bellow Reasonable NormFwd_IAT_Mean ", bellowReasonableNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent reasonableNormFwd_IAT_Mean = new IT2_Antecedent("Reasonable NormFwd_IAT_Mean ", reasonableNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent highNormFwd_IAT_Mean = new IT2_Antecedent("High NormFwd_IAT_Mean ", highNormFwdIATMeanT2MF, normFwdIATMean);
		
		 
		 
		// NormFwd_IAT_Std antecedent 
		 IT2_Antecedent veryLowNormFwd_IAT_Std = new IT2_Antecedent("Very Low NormFwd_IAT_Std ", veryLowNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent lowNormFwd_IAT_Std = new IT2_Antecedent("Low NormFwd_IAT_Std ", lowNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent bellowReasonableNormFwd_IAT_Std = new IT2_Antecedent("Bellow Reasonable NormFwd_IAT_Std ", bellowReasonableNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent reasonableNormFwd_IAT_Std = new IT2_Antecedent("Reasonable NormFwd_IAT_Std ", reasonableNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent highNormFwd_IAT_Std = new IT2_Antecedent("High NormFwd_IAT_Std ", highNormFwdIATStdT2MF, normFwdIATStd);
		 
		 
		 
	     // NormBwd_IAT_Mean antecedent 
		 IT2_Antecedent veryLowNormBwd_IAT_Mean = new IT2_Antecedent("Very Low NormBwd_IAT_Mean ", veryLowNormFwdIATStdT2MF, normBwdIATMean);
		 IT2_Antecedent lowNormBwd_IAT_Mean = new IT2_Antecedent("Low NormBwd_IAT_Mean ", lowNormFwdIATStdT2MF, normBwdIATMean);
		 IT2_Antecedent bellowReasonableNormBwd_IAT_Mean = new IT2_Antecedent("Bellow Reasonable NormBwd_IAT_Mean ", bellowReasonableNormBwdIATMeanT2MF, normBwdIATMean);
		 IT2_Antecedent reasonableNormBwd_IAT_Mean = new IT2_Antecedent("Reasonable NormBwd_IAT_Mean ", reasonableNormBwdIATMeanT2MF, normBwdIATMean);
		 IT2_Antecedent highNormBwd_IAT_Mean = new IT2_Antecedent("High NormBwd_IAT_Mean ", highNormBwdIATMeanT2MF, normBwdIATMean);	
		 
		//NormPacket_Length_Mean antecedent
		 IT2_Antecedent veryLowNormPacket_Length_Mean = new IT2_Antecedent("Very Low NormPacket_Length_Mean ", veryLowNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent lowNormPacket_Length_Mean = new IT2_Antecedent("Low NormPacket_Length_Mean ", lowNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent bellowReasonableNormPacket_Length_Mean = new IT2_Antecedent("Bellow Reasonable NormPacket_Length_Mean ", bellowReasonableNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent reasonableNormPacket_Length_Mean = new IT2_Antecedent("Reasonable NormPacket_Length_Mean ", reasonableNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent highNormPacket_Length_Mean = new IT2_Antecedent("High NormPacket_Length_Mean ", highNormPacketLengthMeanT2MF, normPacketLengthMean);	

        
		// NormPacket_Length_Std antecedent
		 IT2_Antecedent veryLowNormPacket_Length_Std = new IT2_Antecedent("Very Low NormPacket_Length_Mean ", veryLowNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent lowNormPacket_Length_Std = new IT2_Antecedent("Low NormPacket_Length_Mean ", lowNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent bellowReasonableNormPacket_Length_Std = new IT2_Antecedent("Bellow Reasonable NormPacket_Length_Mean ", bellowReasonableNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent reasonableNormPacket_Length_Std = new IT2_Antecedent("Reasonable NormPacket_Length_Mean ", reasonableNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent highNormPacket_Length_Std = new IT2_Antecedent("High NormPacket_Length_Mean ", highNormPacketLengthStdT2MF, normPacketLengthStd);	



         // Video consequent
		 IT2_Consequent lowVideo = new IT2_Consequent("Low Video", lowVideoT2MF, video);
		 IT2_Consequent averageVideo = new IT2_Consequent("Reasonable Video", averageVideoT2MF, video);
		 IT2_Consequent highVideo = new IT2_Consequent("High Video", highVideoT2MF, video);

		System.out.println("Antecedents and consequents setted...");
		
		
		
		// Set up the rulebase and add rules 
		//https://github.com/emmonks/FuzzyNetClass/blob/main/Juzzy/regras_juzzy_video_26112022.txt
		
		rulebase = new IT2_Rulebase(140);
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_IAT_Mean,bellowReasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_IAT_Mean,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Mean,bellowReasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Mean,highNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ bellowReasonableNormPacket_Length_Mean,bellowReasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,bellowReasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,bellowReasonableNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,veryLowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,veryLowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,veryLowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,veryLowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,veryLowNormFwd_IAT_Std,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,bellowReasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,bellowReasonableNormFlow_IAT_Mean,bellowReasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,veryLowNormBwd_IAT_Mean,veryLowNormFlow_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,veryLowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,bellowReasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormFlow_IAT_Mean,highNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,veryLowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,bellowReasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,bellowReasonableNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,veryLowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,bellowReasonableNormBwd_Packet_Length_Std,veryLowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,reasonableNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,veryLowNormFlow_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,veryLowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,bellowReasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormBwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,veryLowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFwd_IAT_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,bellowReasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,veryLowNormFlow_IAT_Std,lowNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,veryLowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,veryLowNormFlow_IAT_Std,veryLowNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,veryLowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormBwd_IAT_Mean,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormBwd_IAT_Mean,veryLowNormFlow_IAT_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,veryLowNormFwd_IAT_Mean,bellowReasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,veryLowNormFwd_IAT_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,veryLowNormFwd_IAT_Mean,veryLowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Mean,veryLowNormFwd_IAT_Mean,veryLowNormFwd_IAT_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,bellowReasonableNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,veryLowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,veryLowNormBwd_IAT_Mean,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,veryLowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,veryLowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFlow_IAT_Std,veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,bellowReasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,bellowReasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,bellowReasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,veryLowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,lowNormFwd_IAT_Mean,bellowReasonableNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,veryLowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,veryLowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,reasonableNormPacket_Length_Std,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,veryLowNormBwd_IAT_Mean,bellowReasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_IAT_Std,veryLowNormFlow_IAT_Mean,veryLowNormFwd_IAT_Mean,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_Packet_Length_Mean,bellowReasonableNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ veryLowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Std },lowVideo));

		
		
		System.out.println("Rulebases setted...");
		
		/*
		normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd, normFlowIATMean, normFlowIATStd,
		normFwdIATMean, normFwdIATStd, normBwdIATMean, normPacketLengthMean, normPacketLengthStd
		*/
		//getClassification(5.5, 3.6, 5.2, 6.0, 3.0, 5.9, 4.3, 3.2, 2.1, 6.8, 9.4);
		

		
		
		//inicio aqui leitura e gravação em arquivo
		
		//String fileName = "final_clean.csv"; 
		String fileName = "dataset_25092022_D.csv";
		System.out.println("Reading Network flows dataset...");
		File dataset = new File("data" + File.separator + fileName);
		String line = new String();
		String[] data = new String[12];
		Scanner lineScan = new Scanner(dataset, "UTF-8");
		lineScan.nextLine();    
		
	    //Creating the output file
		
		int posPonto = fileName.indexOf(".");
		String outputFileName = fileName.substring(0, posPonto)+"_redutor_centroid_output_regras_5termos_T7_29122022.csv";
		
		
	    //String outputFileName = fileName + "output-" + java.time.LocalDateTime.now() + ".csv";
	    FileOutputStream outputFLSFile = new FileOutputStream("data/" + outputFileName);
	    
	    System.out.println("Starting FLS...");
	    

		StringBuffer outputFLS = new StringBuffer();
		outputFLS.append("Sequencial, NormFwd_Packet_Length_Mean, NormFwd_Packet_Length_Std, NormBwd_Packet_Length_Mean, NormBwd_Packet_Length_Std, "
				+ "NormFlow_IAT_Mean, NormFlow_IAT_Std, NormFwd_IAT_Mean, NormFwd_IAT_Std, NormBwd_IAT_Mean, NormPacket_Length_Mean, "
				+ "NormPacket_Length_Std, Label, linguisticClassification, accuracy, xPonctual, xInf, xSup, lowerLowVideo, upperLowVideo, lowerAverageVideo, upperAverageVideo,"
				+ " lowerHighVideo,  upperHighVideo, "
				
				// input normFwdPacketLengthMean
				+ " lowerVeryLowNormFwdPacketLengthMean, upperVeryLowNormFwdPacketLengthMean,"
				+ " lowerLowNormFwdPacketLengthMean, upperLowNormFwdPacketLengthMean,"
				+ " lowerBellowReasonableNormFwdPacketLengthMean, upperBellowReasonableNormFwdPacketLengthMean, "
				+ " lowerReasonableNormFwdPacketLengthMean, upperReasonableNormFwdPacketLengthMean, "
				+ " lowerHighNormFwdPacketLengthMean, upperHighNormFwdPacketLengthMean, "
				
				// input normFwdPacketLengthStd
                + " lowerVeryLowNormFwdPacketLengthStd, upperVeryLowNormFwdPacketLengthStd, "
                + " lowerLowNormFwdPacketLengthStd, upperLowNormFwdPacketLengthStd, "
                + " lowerBellowReasonableNormFwdPacketLengthStd, upperBellowReasonableNormFwdPacketLengthStd, "
                + " lowerReasonableNormFwdPacketLengthStd, upperReasonableNormFwdPacketLengthStd, "
                + " lowerHighNormFwdPacketLengthStd, upperHighNormFwdPacketLengthStd, "
                
                //  input normBwdPacketLengthMean
                + " lowerVeryLowNormBwdPacketLengthMean, upperVeryLowNormBwdPacketLengthMean, "
                + " lowerLowNormBwdPacketLengthMean, upperLowNormBwdPacketLengthMean, "
                + " lowerBellowReasonableNormBwdPacketLengthMean, upperBellowReasonableNormBwdPacketLengthMean, "
                + " lowerReasonableNormBwdPacketLengthMean, upperReasonableNormBwdPacketLengthMean, "
                + " lowerHighNormBwdPacketLengthMean, upperHighNormBwdPacketLengthMean, "
                
                // input normBwdPacketLengthStd
                + " lowerVeryLowNormBwdPacketLengthStd, upperVeryLowNormBwdPacketLengthStd, "
                + " lowerLowNormBwdPacketLengthStd, upperLowNormBwdPacketLengthStd, "
                + " lowerBellowReasonableNormBwdPacketLengthStd, upperBellowReasonableNormBwdPacketLengthStd, "
                + " lowerReasonableNormBwdPacketLengthStd, upperReasonableNormBwdPacketLengthStd, "
                + " lowerHighNormBwdPacketLengthStd, upperHighNormBwdPacketLengthStd, "
                
                // input normFlowIATMean
                + " lowerVeryLowNormFlowIATMean, upperVeryLowNormFlowIATMean, "
                + " lowerLowNormFlowIATMean, upperLowNormFlowIATMean, "
                + " lowerBellowReasonableNormFlowIATMean, upperBellowReasonableNormFlowIATMean, "
                + " lowerReasonableNormFlowIATMean, upperReasonableNormFlowIATMean, "
                + " lowerHighNormFlowIATMean, upperHighNormFlowIATMean, "
                
                // input normFlowIATStd
                + " lowerVeryLowNormFlowIATStd, upperVeryLowNormFlowIATStd, "
                + " lowerLowNormFlowIATStd, upperLowNormFlowIATStd, "
                + " lowerBellowReasonableNormFlowIATStd, upperBellowReasonableNormFlowIATStd, "
                + " lowerReasonableNormFlowIATStd, upperReasonableNormFlowIATStd, "
                + " lowerHighNormFlowIATStd, upperHighNormFlowIATStd, "
                
                // input normFwdIATMean
                + " lowerVeryLowNormFwdIATMean, upperVeryLowNormFwdIATMean, "
                + " lowerLowNormFwdIATMean, upperLowNormFwdIATMean, "
                + " lowerBellowReasonableNormFwdIATMean, upperBellowReasonableNormFwdIATMean, "
                + " lowerReasonableNormFwdIATMean, upperReasonableNormFwdIATMean, "
                + " lowerHighNormFwdIATMean, upperHighNormFwdIATMean, "
                
                // input normFwdIATStd
                + " lowerVeryLowNormFwdIATStd, upperVeryLowNormFwdIATStd, "
                + " lowerLowNormFwdIATStd, upperLowNormFwdIATStd, "
                + " lowerBellowReasonableNormFwdIATStd, upperBellowReasonableNormFwdIATStd, "
                + " lowerReasonableNormFwdIATStd, upperReasonableNormFwdIATStd, "
                + " lowerHighNormFwdIATStd, upperHighNormFwdIATStd, "

                // input normPacketLengthMean 
                + " lowerVeryLowNormPacketLengthMean, upperVeryLowNormPacketLengthMean, "
                + " lowerLowNormPacketLengthMean, upperLowNormPacketLengthMean, "
                + " lowerBellowReasonalbeNormPacketLengthMean, upperBellowReasonableNormPacketLengthMean, "
                + " lowerReasonalbeNormPacketLengthMean, upperReasonableNormPacketLengthMean, "
                + " lowerHighNormPacketLengthMean, upperHighNormPacketLengthMean, "
                
                // input normPacketLengthStd
                + " lowerVeryLowNormPacketLengthStd, upperVeryLowNormPacketLengthStd, "
                + " lowerLowNormPacketLengthStd, upperLowNormPacketLengthStd, "
                + " lowerBellowReasonableNormPacketLengthStd, upperBellowReasonalbeNormPacketLengthStd, "
                + " lowerReasonableNormPacketLengthStd, upperReasonalbeNormPacketLengthStd, "
                + " lowerHighNormPacketLengthStd, upperHighNormPacketLengthStd, "
                
                //input normBwdIATMean
                + " lowerVeryLowNormBwdIATMean, upperVeryLowNormBwdIATMean, "
                + " lowerLowNormBwdIATMean, upperLowNormBwdIATMean, "
                + " lowerBellowReasonableNormBwdIATMean, upperBellowReasonalbeNormBwdIATMean, "
                + " lowerReasonableNormBwdIATMean, upperReasonalbeNormBwdIATMean, "
                + " lowerHighNormBwdIATMean, upperHighNormBwdIATMean "

                
				
				).append("\n");
		
		
		outputFLSFile.write(outputFLS.toString().getBytes());
		
		
		
		int x=0;
		while(lineScan.hasNext()) {
			x++;
			line = lineScan.nextLine();
			
			//split the dataset line by semicolon
			data = line.split(",");
			
			outputFLS = new StringBuffer();
			
			
			double normFwdPacketLengthMean = Double.valueOf(data[0]); 
			double normFwdPacketLengthStd = Double.valueOf(data[1]);
			double normBwdPacketLengthMean = Double.valueOf(data[2]);
			double normBwdPacketLengthStd = Double.valueOf(data[3]);
			double normFlowIATMean = Double.valueOf(data[4]);
			double normFlowIATStd = Double.valueOf(data[5]);
			double normFwdIATMean = Double.valueOf(data[6]);
			double normFwdIATStd = Double.valueOf(data[7]);
			double normBwdIATMean = Double.valueOf(data[8]);
			double normPacketLengthMean = Double.valueOf(data[9]);
			double normPacketLengthStd = Double.valueOf(data[10]);
			
			// Get degree membership
			 
			
			
			
			Double point = getClassification(normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd,
					normFlowIATMean, normFlowIATStd, normFwdIATMean, normFwdIATStd,normBwdIATMean, normPacketLengthMean, normPacketLengthStd);
			
			
			double  upperLowVideo = lowVideoT2MF.getUpperBound(point);
			double  lowerLowVideo = lowVideoT2MF.getLowerBound(point);
			
			double  upperAverageVideo  = averageVideoT2MF.getUpperBound(point);
			double  lowerAverageVideo  = averageVideoT2MF.getLowerBound(point);
			
			double upperHighVideo = highVideoT2MF.getUpperBound(point);
			double lowerHighVideo = highVideoT2MF.getLowerBound(point);
			
			double avgLowVideo = (upperLowVideo + lowerLowVideo)/2;
			double avgAverageVideo = (upperAverageVideo + lowerAverageVideo)/2;
			double avgHighVideo = (upperHighVideo + lowerHighVideo)/2;
			
			/*
			 * 	String linguisticClassification;
	            int accuracy;
	            int accuracyCount = 0;
		   */
			
			if((avgLowVideo > avgAverageVideo) && (avgLowVideo > avgHighVideo)){
				linguisticClassification = "lowVideo";
				
			}else if((avgAverageVideo > avgLowVideo) && (avgAverageVideo > avgHighVideo)) {
				linguisticClassification = "averageVideo";
				
			}else if((avgHighVideo > avgLowVideo) && (avgHighVideo > avgAverageVideo)) {
				linguisticClassification = "highVideo";
			}
			
			accuracy = 0;
			
			if (linguisticClassification.equals("highVideo")){
				
				if((data[11].toString().equals("vod")) || (data[11].toString().equals("live"))) {
					
					accuracy = 1;
					accuracyCount++;
					
				}
				
			}else if(linguisticClassification.equals("averageVideo")) {

				if((data[11].toString().equals("https")) || (data[11].toString().equals("quic"))) {
					
					accuracy = 1;
					accuracyCount++;
				}

				
			}else if(linguisticClassification.equals("lowVideo")) {
				
				if((data[11].toString().equals("http")) || (data[11].toString().equals("outros")) ||
						(data[11].toString().equals("dns"))) {
					
					accuracy = 1;
					accuracyCount++;
					
					}
				
			}else {
				accuracy = 0;
			}

			
			
			// BigDecimal bd = new BigDecimal(point).setScale(4, RoundingMode.UP);
			
			// Write the FLS output of network classification
			outputFLS.append(x).append(", ") // Sequencial
			.append(data[0]).append(", ") // NormFwd_Packet_Length_Mean
			.append(data[1]).append(", ") // NormFwd_Packet_Length_Std
			.append(data[2]).append(", ") // NormBwd_Packet_Length_Mean
			.append(data[3]).append(", ") // NormBwd_Packet_Length_Std
			.append(data[4]).append(", ") // NormFlow_IAT_Mean
			.append(data[5]).append(", ") // NormFlow_IAT_Std
			.append(data[6]).append(", ") // NormFwd_IAT_Mean
			.append(data[7]).append(", ") // NormFwd_IAT_Std
			.append(data[8]).append(", ") // NormBwd_IAT_Mean
			.append(data[9]).append(", ") // NormPacket_Length_Mean
			.append(data[10]).append(", ") // NormPacket_Length_Std
			.append(data[11]).append(", ") // Label
			.append(linguisticClassification).append(", ") // linguisticClassification
			.append(accuracy).append(", ") // accuracy
			.append(point) .append(", ")
			.append(this.OutputXValue).append(", ")
			.append(this.OutputYValue).append(", ")
			.append(lowerLowVideo).append(", ")
			.append(upperLowVideo).append(", ")
			.append(lowerAverageVideo).append(", ")
			.append(upperAverageVideo).append(", ")
			.append(lowerHighVideo).append(", ")
			.append(upperHighVideo).append(", ")

			// getting degree membership inputs
			
			// input normFwdPacketLengthMean
			.append(veryLowNormFwdPacketLengthMeanT2MF.getLowerBound(normFwdPacketLengthMean)).append(", ") 
			.append(veryLowNormFwdPacketLengthMeanT2MF.getUpperBound(normFwdPacketLengthMean)).append(", ") 
			
			.append(lowNormFwdPacketLengthMeanT2MF.getLowerBound(normFwdPacketLengthMean)).append(", ")
			.append(lowNormFwdPacketLengthMeanT2MF.getUpperBound(normFwdPacketLengthMean)).append(", ")

			.append(bellowReasonableNormFwdPacketLengthMeanT2MF.getLowerBound(normFwdPacketLengthMean)).append(", ")
			.append(bellowReasonableNormFwdPacketLengthMeanT2MF.getUpperBound(normFwdPacketLengthMean)).append(", ")
			
			.append(reasonableNormFwdPacketLengthMeanT2MF.getLowerBound(normFwdPacketLengthMean)).append(", ")
			.append(reasonableNormFwdPacketLengthMeanT2MF.getUpperBound(normFwdPacketLengthMean)).append(", ")
			
			.append(highNormFwdPacketLengthMeanT2MF.getLowerBound(normFwdPacketLengthMean)).append(", ")
			.append(highNormFwdPacketLengthMeanT2MF.getUpperBound(normFwdPacketLengthMean)).append(", ")
			
			// input normFwdPacketLengthStd
			.append(veryLowNormFwdPacketLengthStdT2MF.getLowerBound(normFwdPacketLengthStd)).append(", ") 
			.append(veryLowNormFwdPacketLengthStdT2MF.getUpperBound(normFwdPacketLengthStd)).append(", ")
			
			.append(lowNormFwdPacketLengthStdT2MF.getLowerBound(normFwdPacketLengthStd)).append(", ") 
			.append(lowNormFwdPacketLengthStdT2MF.getUpperBound(normFwdPacketLengthStd)).append(", ")
			
			.append(bellowReasonableNormFwdPacketLengthStdT2MF.getLowerBound(normFwdPacketLengthStd)).append(", ") 
			.append(bellowReasonableNormFwdPacketLengthStdT2MF.getUpperBound(normFwdPacketLengthStd)).append(", ")
			
			.append(reasonableNormFwdPacketLengthStdT2MF.getLowerBound(normFwdPacketLengthStd)).append(", ") 
			.append(reasonableNormFwdPacketLengthStdT2MF.getUpperBound(normFwdPacketLengthStd)).append(", ")
			
			.append(highNormFwdPacketLengthStdT2MF.getLowerBound(normFwdPacketLengthStd)).append(", ") 
			.append(highNormFwdPacketLengthStdT2MF.getUpperBound(normFwdPacketLengthStd)).append(", ") 
			
			// input normBwdPacketLengthMean
			.append(veryLowNormBwdPacketLengthMeanT2MF.getLowerBound(normBwdPacketLengthMean)).append(", ") 
			.append(veryLowNormBwdPacketLengthMeanT2MF.getUpperBound(normBwdPacketLengthMean)).append(", ")
			
			.append(lowNormBwdPacketLengthMeanT2MF.getLowerBound(normBwdPacketLengthMean)).append(", ") 
			.append(lowNormBwdPacketLengthMeanT2MF.getUpperBound(normBwdPacketLengthMean)).append(", ")
			
			.append(bellowReasonableNormBwdPacketLengthMeanT2MF.getLowerBound(normBwdPacketLengthMean)).append(", ") 
			.append(bellowReasonableNormBwdPacketLengthMeanT2MF.getUpperBound(normBwdPacketLengthMean)).append(", ")
			
			.append(reasonableNormBwdPacketLengthMeanT2MF.getLowerBound(normBwdPacketLengthMean)).append(", ") 
			.append(reasonableNormBwdPacketLengthMeanT2MF.getUpperBound(normBwdPacketLengthMean)).append(", ")
			
			.append(highNormBwdPacketLengthMeanT2MF.getLowerBound(normBwdPacketLengthMean)).append(", ") 
			.append(highNormBwdPacketLengthMeanT2MF.getUpperBound(normBwdPacketLengthMean)).append(", ")

            // input normBwdPacketLengthStd
			.append(veryLowNormBwdPacketLengthStdT2MF.getLowerBound(normBwdPacketLengthStd)).append(", ") 
			.append(veryLowNormBwdPacketLengthStdT2MF.getUpperBound(normBwdPacketLengthStd)).append(", ")
			
			.append(lowNormBwdPacketLengthStdT2MF.getLowerBound(normBwdPacketLengthStd)).append(", ") 
			.append(lowNormBwdPacketLengthStdT2MF.getUpperBound(normBwdPacketLengthStd)).append(", ")
			
			.append(bellowReasonableNormBwdPacketLengthStdT2MF.getLowerBound(normBwdPacketLengthStd)).append(", ") 
			.append(bellowReasonableNormBwdPacketLengthStdT2MF.getUpperBound(normBwdPacketLengthStd)).append(", ")
			
			.append(reasonableNormBwdPacketLengthStdT2MF.getLowerBound(normBwdPacketLengthStd)).append(", ") 
			.append(reasonableNormBwdPacketLengthStdT2MF.getUpperBound(normBwdPacketLengthStd)).append(", ")
			
			.append(highNormBwdPacketLengthStdT2MF.getLowerBound(normBwdPacketLengthStd)).append(", ") 
			.append(highNormBwdPacketLengthStdT2MF.getUpperBound(normBwdPacketLengthStd)).append(", ")
			
			// input normFlowIATMean
			.append(veryLowNormFlowIATMeanT2MF.getLowerBound(normFlowIATMean)).append(", ")
			.append(veryLowNormFlowIATMeanT2MF.getUpperBound(normFlowIATMean)).append(", ")
			
			.append(lowNormFlowIATMeanT2MF.getLowerBound(normFlowIATMean)).append(", ")
			.append(lowNormFlowIATMeanT2MF.getUpperBound(normFlowIATMean)).append(", ")
			
			.append(bellowReasonableNormFlowIATMeanT2MF.getLowerBound(normFlowIATMean)).append(", ")
			.append(bellowReasonableNormFlowIATMeanT2MF.getUpperBound(normFlowIATMean)).append(", ")
			
			.append(reasonableNormFlowIATMeanT2MF.getLowerBound(normFlowIATMean)).append(", ")
			.append(reasonableNormFlowIATMeanT2MF.getUpperBound(normFlowIATMean)).append(", ")
			
			.append(highNormFlowIATMeanT2MF.getLowerBound(normFlowIATMean)).append(", ")
			.append(highNormFlowIATMeanT2MF.getUpperBound(normFlowIATMean)).append(", ")
			
			// input normFlowIATStd
			.append(veryLowNormFlowIATStdT2MF.getLowerBound(normFlowIATStd)).append(", ")
			.append(veryLowNormFlowIATStdT2MF.getUpperBound(normFlowIATStd)).append(", ")
			
			.append(lowNormFlowIATStdT2MF.getLowerBound(normFlowIATStd)).append(", ")
			.append(lowNormFlowIATStdT2MF.getUpperBound(normFlowIATStd)).append(", ")
			
			.append(bellowReasonableNormFlowIATStdT2MF.getLowerBound(normFlowIATStd)).append(", ")
			.append(bellowReasonableNormFlowIATStdT2MF.getUpperBound(normFlowIATStd)).append(", ")
			
			.append(reasonableNormFlowIATStdT2MF.getLowerBound(normFlowIATStd)).append(", ")
			.append(reasonableNormFlowIATStdT2MF.getUpperBound(normFlowIATStd)).append(", ")
			
			.append(highNormFlowIATStdT2MF.getLowerBound(normFlowIATStd)).append(", ")
			.append(highNormFlowIATStdT2MF.getUpperBound(normFlowIATStd)).append(", ")
			
			 // input normFwdIATMean
			.append(veryLowNormFwdIATMeanT2MF.getLowerBound(normFwdIATMean)).append(", ")
			.append(veryLowNormFwdIATMeanT2MF.getUpperBound(normFwdIATMean)).append(", ")
			
			.append(lowNormFwdIATMeanT2MF.getLowerBound(normFwdIATMean)).append(", ")
			.append(lowNormFwdIATMeanT2MF.getUpperBound(normFwdIATMean)).append(", ")
			
			.append(bellowReasonableNormFwdIATMeanT2MF.getLowerBound(normFwdIATMean)).append(", ")
			.append(bellowReasonableNormFwdIATMeanT2MF.getUpperBound(normFwdIATMean)).append(", ")
			
			.append(reasonableNormFwdIATMeanT2MF.getLowerBound(normFwdIATMean)).append(", ")
			.append(reasonableNormFwdIATMeanT2MF.getUpperBound(normFwdIATMean)).append(", ")
			
			.append(highNormFwdIATMeanT2MF.getLowerBound(normFwdIATMean)).append(", ")
			.append(highNormFwdIATMeanT2MF.getUpperBound(normFwdIATMean)).append(", ")

            // input normFwdIATStd
			.append(veryLowNormFwdIATStdT2MF.getLowerBound(normFwdIATStd)).append(", ")
			.append(veryLowNormFwdIATStdT2MF.getUpperBound(normFwdIATStd)).append(", ")
			
			.append(lowNormFwdIATStdT2MF.getLowerBound(normFwdIATStd)).append(", ")
			.append(lowNormFwdIATStdT2MF.getUpperBound(normFwdIATStd)).append(", ")
			
			.append(bellowReasonableNormFwdIATStdT2MF.getLowerBound(normFwdIATStd)).append(", ")
			.append(bellowReasonableNormFwdIATStdT2MF.getUpperBound(normFwdIATStd)).append(", ")
			
			.append(reasonableNormFwdIATStdT2MF.getLowerBound(normFwdIATStd)).append(", ")
			.append(reasonableNormFwdIATStdT2MF.getUpperBound(normFwdIATStd)).append(", ")

			.append(highNormFwdIATStdT2MF.getLowerBound(normFwdIATStd)).append(", ")
			.append(highNormFwdIATStdT2MF.getUpperBound(normFwdIATStd)).append(", ")
			
            // input normPacketLengthMean
			.append(veryLowNormPacketLengthMeanT2MF.getLowerBound(normPacketLengthMean)).append(", ")
			.append(veryLowNormPacketLengthMeanT2MF.getUpperBound(normPacketLengthMean)).append(", ")
			
			.append(lowNormPacketLengthMeanT2MF.getLowerBound(normPacketLengthMean)).append(", ")
			.append(lowNormPacketLengthMeanT2MF.getUpperBound(normPacketLengthMean)).append(", ")
			
			.append(bellowReasonableNormPacketLengthMeanT2MF.getLowerBound(normPacketLengthMean)).append(", ")
			.append(bellowReasonableNormPacketLengthMeanT2MF.getUpperBound(normPacketLengthMean)).append(", ")
			
			.append(reasonableNormPacketLengthMeanT2MF.getLowerBound(normPacketLengthMean)).append(", ")
			.append(reasonableNormPacketLengthMeanT2MF.getUpperBound(normPacketLengthMean)).append(", ")
			
			.append(highNormPacketLengthMeanT2MF.getLowerBound(normPacketLengthMean)).append(", ")
			.append(highNormPacketLengthMeanT2MF.getUpperBound(normPacketLengthMean)).append(", ")
			
            // input normPacketLengthStd
			.append(veryLowNormPacketLengthStdT2MF.getLowerBound(normPacketLengthStd)).append(", ")
			.append(veryLowNormPacketLengthStdT2MF.getUpperBound(normPacketLengthStd)).append(", ")
			
			.append(lowNormPacketLengthStdT2MF.getLowerBound(normPacketLengthStd)).append(", ")
			.append(lowNormPacketLengthStdT2MF.getUpperBound(normPacketLengthStd)).append(", ")
			
			.append(bellowReasonableNormPacketLengthStdT2MF.getLowerBound(normPacketLengthStd)).append(", ")
			.append(bellowReasonableNormPacketLengthStdT2MF.getUpperBound(normPacketLengthStd)).append(", ")
			
			.append(reasonableNormPacketLengthStdT2MF.getLowerBound(normPacketLengthStd)).append(", ")
			.append(reasonableNormPacketLengthStdT2MF.getUpperBound(normPacketLengthStd)).append(", ")
			
			.append(highNormPacketLengthStdT2MF.getLowerBound(normPacketLengthStd)).append(", ")
			.append(highNormPacketLengthStdT2MF.getUpperBound(normPacketLengthStd)).append(", ")
			
			 //input normBwdIATMean
			.append(veryLowNormBwdIATMeanT2MF.getLowerBound(normBwdIATMean)).append(", ")
			.append(veryLowNormBwdIATMeanT2MF.getUpperBound(normBwdIATMean)).append(", ")
			
			.append(lowNormBwdIATMeanT2MF.getLowerBound(normBwdIATMean)).append(", ")
			.append(lowNormBwdIATMeanT2MF.getUpperBound(normBwdIATMean)).append(", ")
			
			.append(bellowReasonableNormBwdIATMeanT2MF.getLowerBound(normBwdIATMean)).append(", ")
			.append(bellowReasonableNormBwdIATMeanT2MF.getUpperBound(normBwdIATMean)).append(", ")
			
			.append(reasonableNormBwdIATMeanT2MF.getLowerBound(normBwdIATMean)).append(", ")
			.append(reasonableNormBwdIATMeanT2MF.getUpperBound(normBwdIATMean)).append(", ")

			.append(highNormBwdIATMeanT2MF.getLowerBound(normBwdIATMean)).append(", ")
			.append(highNormBwdIATMeanT2MF.getUpperBound(normBwdIATMean)).append(", ")
			
			
			.append("\n");
			

			
			outputFLSFile.write(outputFLS.toString().getBytes());
			
		}
		outputFLSFile.close();
		lineScan.close();
		
		System.out.println("Output file generated!");
		
		//fim da leitura e processamento do dataset
		
		
		
		

		// plot some sets, discretizing each input into 100 steps.
		
		plotMFs("normFwdPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface [] { veryLowNormFwdPacketLengthMeanT2MF, lowNormFwdPacketLengthMeanT2MF, bellowReasonableNormFwdPacketLengthMeanT2MF, reasonableNormFwdPacketLengthMeanT2MF, highNormFwdPacketLengthMeanT2MF},
				normFwdPacketLengthMean.getDomain(), 100);
		
		/*
		plotMFs("normFwdPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormFwdPacketLengthStdT2MF, lowNormFwdPacketLengthStdT2MF, bellowReasonableNormFwdPacketLengthStdT2MF, reasonableNormFwdPacketLengthStdT2MF, highNormFwdPacketLengthStdT2MF },
				normFwdPacketLengthStd.getDomain(), 100);
		
		
		plotMFs("normBwdPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormBwdPacketLengthMeanT2MF, lowNormBwdPacketLengthMeanT2MF, bellowReasonableNormBwdPacketLengthMeanT2MF, reasonableNormBwdPacketLengthMeanT2MF, highNormBwdPacketLengthMeanT2MF },
				normBwdPacketLengthMean.getDomain(), 100);
		
		
		plotMFs("normBwdPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormBwdPacketLengthStdT2MF, lowNormBwdPacketLengthStdT2MF, bellowReasonableNormBwdPacketLengthStdT2MF , reasonableNormBwdPacketLengthStdT2MF, highNormBwdPacketLengthStdT2MF },
				normBwdPacketLengthStd.getDomain(), 100);
		
		
		plotMFs("normFlowIATMean Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormFlowIATMeanT2MF, lowNormFlowIATMeanT2MF, bellowReasonableNormFlowIATMeanT2MF, reasonableNormFlowIATMeanT2MF, highNormFlowIATMeanT2MF },
				normFlowIATMean.getDomain(), 100);
		
		
		plotMFs("normFlowIATStd Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormFlowIATStdT2MF, lowNormFlowIATStdT2MF, bellowReasonableNormFlowIATStdT2MF, reasonableNormFlowIATStdT2MF, highNormFlowIATStdT2MF },
				normFlowIATStd.getDomain(), 100);
		
		plotMFs("normFlowIATMean Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormFwdIATMeanT2MF, lowNormFwdIATMeanT2MF, bellowReasonableNormFwdIATMeanT2MF, reasonableNormFwdIATMeanT2MF, highNormFwdIATMeanT2MF },
				normFlowIATMean.getDomain(), 100);
		
		plotMFs("normFlowIATStd Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormFwdIATStdT2MF, lowNormFwdIATStdT2MF, bellowReasonableNormFwdIATStdT2MF, reasonableNormFwdIATStdT2MF, highNormFwdIATStdT2MF  },
				normFlowIATStd.getDomain(), 100);
		
		plotMFs("normBwdIATMean Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormBwdIATMeanT2MF, lowNormBwdIATMeanT2MF, bellowReasonableNormBwdIATMeanT2MF, reasonableNormBwdIATMeanT2MF, highNormBwdIATMeanT2MF },
				normBwdIATMean.getDomain(), 100);
		
		plotMFs("normPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormPacketLengthMeanT2MF, lowNormPacketLengthMeanT2MF, bellowReasonableNormPacketLengthMeanT2MF, reasonableNormPacketLengthMeanT2MF, highNormPacketLengthMeanT2MF },
				normPacketLengthMean.getDomain(), 100);

		plotMFs("normPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { veryLowNormPacketLengthStdT2MF, lowNormPacketLengthStdT2MF, bellowReasonableNormPacketLengthStdT2MF, reasonableNormPacketLengthStdT2MF, highNormPacketLengthStdT2MF },
				normPacketLengthStd.getDomain(), 100);
		
        */

		plotMFs("Video Membership Functions",
				new IntervalT2MF_Interface[] { lowVideoT2MF, averageVideoT2MF, highVideoT2MF  },
				video.getDomain(), 100);
		
		
       /*
		// plot control surface
		// do either height defuzzification (false) or centroid d. (true)
		plotControlSurface(true, 10, 10);

		// print out the rules
		System.out.println("\n" + rulebase);
		
		*/
		 
		 
	}

	/**
	 * Basic method that prints the output for a given set of inputs.
	 * 
	 * @param negativityMeasure
	 * @param positivityMeasure
	 * @throws IOException
	 */

	private Double getClassification(double normFwdPacketLengthMean, double normFwdPacketLengthStd, double normBwdPacketLengthMean, double normBwdPacketLengthStd,
			double normFlowIATMean, double normFlowIATStd, double normFwdIATMean, double normFwdIATStd, double normBwdIATMean, double normPacketLengthMean, double normPacketLengthStd) {
		// first, set the inputs
		this.normFwdPacketLengthMean.setInput(normFwdPacketLengthMean);
		this.normFwdPacketLengthStd.setInput(normFwdPacketLengthStd);
		this.normBwdPacketLengthMean.setInput(normBwdPacketLengthMean);
		this.normBwdPacketLengthStd.setInput(normBwdPacketLengthStd);
		this.normFlowIATMean.setInput(normFlowIATMean);
		this.normFlowIATStd.setInput(normFlowIATStd);
		this.normFwdIATMean.setInput(normFwdIATMean);
		this.normFwdIATStd.setInput(normFwdIATStd);
		this.normBwdIATMean.setInput(normBwdIATMean);
		this.normPacketLengthMean.setInput(normPacketLengthMean);
		this.normPacketLengthStd.setInput(normPacketLengthStd);
		
		// now execute the FLS and print output
//		System.out.println("The negativity measure was: " + negativity.getInput());
//		System.out.println("The positivity measure was: " + positivity.getInput());
//		System.out.println("Using height defuzzification " + rulebase.evaluate(0).get(classification));
//		System.out.println("Using centroid defuzzification " + rulebase.evaluate(1).get(classification));

		//this.OutputXValue = rulebase.evaluateGetCentroid(0)

		// private final byte CENTEROFSETS = 0;
		// private final byte CENTROID = 1;
		
		TreeMap<Output, Object[]> centroid = rulebase.evaluateGetCentroid(1);
    	Object[] centroidTip = centroid.get(video);
        Tuple centroidTipXValues = (Tuple)centroidTip[0];
				
        this.OutputXValue = centroidTipXValues.getLeft();
        this.OutputYValue = centroidTipXValues.getRight();
                
		//return rulebase.evaluate(1).get(classification);
		return centroidTipXValues.getAverage();
		
	}

	private void plotMFs(String name, IntervalT2MF_Interface[] sets, Tuple xAxisRange, int discretizationLevel) {
		JMathPlotter plotter = new JMathPlotter();
		for (int i = 0; i < sets.length; i++) {
			plotter.plotMF(sets[i].getName(), sets[i], discretizationLevel, null, false);
		}
		plotter.show(name);
	}

	private void plotControlSurface(boolean useCentroidDefuzzification, int input1Discs, int input2Discs) {
		double output;
		double[] x = new double[input1Discs];
		double[] y = new double[input2Discs];
		double[][] z = new double[y.length][x.length];
		double incrX, incrY;
		incrX = normFwdPacketLengthMean.getDomain().getSize() / (input1Discs - 1.0);
		incrY = normFwdPacketLengthStd.getDomain().getSize() / (input2Discs - 1.0);

		// first, get the values
		for (int currentX = 0; currentX < input1Discs; currentX++) {
			x[currentX] = currentX * incrX;
		}
		for (int currentY = 0; currentY < input2Discs; currentY++) {
			y[currentY] = currentY * incrY;
		}

		for (int currentX = 0; currentX < input1Discs; currentX++) {
			normFwdPacketLengthMean.setInput(x[currentX]);
			for (int currentY = 0; currentY < input2Discs; currentY++) {
				normFwdPacketLengthStd.setInput(y[currentY]);
				if (useCentroidDefuzzification)
					output = rulebase.evaluate(1).get(video);
				else
					output = rulebase.evaluate(0).get(video);
				z[currentY][currentX] = output;
			}
		}

		// now do the plotting
		JMathPlotter plotter = new JMathPlotter(17, 17, 14);
		plotter.plotControlSurface("Control Surface",
				new String[] { normFwdPacketLengthMean.getName(), normFwdPacketLengthStd.getName(), "Video" }, x, y, z,
				new Tuple(0.0, 1.0), true);
		plotter.show("Type-1 Fuzzy Logic System Control Surface for Sentiment Analysis");
	}

	public static void main(String args[]) throws IOException {
		new FuzzyClassifyNetworkTrafic();
	}
}