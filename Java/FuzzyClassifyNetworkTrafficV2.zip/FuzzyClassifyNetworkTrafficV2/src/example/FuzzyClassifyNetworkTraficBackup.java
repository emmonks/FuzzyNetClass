/*
 * Sentiment.java
 *
 * Created on Oct 07th 2022
 *
 * Based on Juzzy by Christian Wagner
 */
package example;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeMap;

import generic.Input;
import generic.Output;
import generic.Tuple;
import intervalType2.sets.IntervalT2MF_Interface;
import intervalType2.sets.IntervalT2MF_Trapezoidal;
import intervalType2.sets.IntervalT2MF_Triangular;
import intervalType2.system.IT2_Antecedent;
import intervalType2.system.IT2_Consequent;
import intervalType2.system.IT2_Rule;
import intervalType2.system.IT2_Rulebase;
import tools.JMathPlotter;
import type1.sets.T1MF_Trapezoidal;
import type1.sets.T1MF_Triangular;

/**
 * A simple example of a type-1 FLS based on the "Sentiment Analysis".
 * 
 * @author Rafael Bastos
 */
public class FuzzyClassifyNetworkTraficBackup {
	
	// the inputs to the FLS
	Input normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd, normFlowIATMean,
	normFlowIATStd, normFwdIATMean, normFwdIATStd, normBwdIATMean, normPacketLengthMean, normPacketLengthStd;
	
	// the output of the FLS
	Output video; 
	// the rulebase captures the entire FLS
	IT2_Rulebase rulebase; 
	
	String linguisticClassification;
	int accuracy;
	int accuracyCount = 0;
	
	private Double OutputXValue;
    private Double OutputYValue;

	public FuzzyClassifyNetworkTraficBackup() throws IOException {

		System.out.println("Starting system...");
		
		// Define the inputs
		normFwdPacketLengthMean = new Input("NormFwd_Packet_Length_Mean degree", new Tuple(0, 10));
		normFwdPacketLengthStd = new Input("NormFwd_PacketLengthStd degree", new Tuple(0, 10));
		normBwdPacketLengthMean = new Input("NormBwd_Packet_Length_Mean degree", new Tuple(0, 10));
		normBwdPacketLengthStd = new Input("NormBwd_Packet_Length_Std degree", new Tuple(0, 10));
		normFlowIATMean = new Input("NormFlow_IAT_Mean degree", new Tuple(0, 10));
		normFlowIATStd = new Input("NormFlow_IAT_Std degree", new Tuple(0, 10));
		normFwdIATMean = new Input("NormFwd_IAT_Mean degree", new Tuple(0, 10));
		normFwdIATStd = new Input("NormFwd_IAT_Std degree", new Tuple(0, 10));
		normBwdIATMean = new Input("NormBwd_IAT_Mean degree", new Tuple(0, 10));
		normPacketLengthMean  = new Input("NormPacket_Length_Mean degree", new Tuple(0, 10));
		normPacketLengthStd  = new Input("NormPacket_Length_Std degree", new Tuple(0, 10));
		
		
		// Define the output
		video = new Output("Video classification", new Tuple(0, 10));
		
		
		//String n, double start, double peak, double end
		
		//Very Low
		double startUpperVeryLowLimit = -7.5;   
		double peakUpperVeryLowLimit =  0.0;   
		double endUpperVeryLowLimit =  7.5;   
		
		double startLowerVeryLowLimit = -5.0; 
		double peakLowerVeryLowLimit =  0.0; 
		double endLowerVeryLowLimit =   5.0;
		
		
		
		// Low
		double startUpperLowLimit = -7.5;   
		double peakUpperLowLimit =  0.0;   
		double endUpperLowLimit =  7.5;   
		
		double startLowerLowLimit = -5.0; 
		double peakLowerLowLimit =  0.0; 
		double endLowerLowLimit =   5.0;
		
		// Below Reasonable
		

	    // Reasonable	
		double startUpperReasonableLimit = -2.5; 
		double peakUpperReasonableLimit =  5.0; 
		double endUpperReasonableLimit =   12.5; 
		
		double startLowerReasonableLimit = 0.0; 
		double peakLowerReasonableLimit =  5.0; 
		double endLowerReasonableLimit =  10.0; 

		
		//High
		double startUpperHighLimit = 2.5; 
		double peakUpperHighLimit = 10; 
		double endUpperHighLimit =  17.5; 
		
		double startLowerHighLimit = 5.0; 
		double peakLowerHighLimit = 10.0; 
		double endLowerHighLimit = 15.0; 


		// Set up the membership functions (MFs) for each input and output

		// NormFwd_Packet_Length_Mean input
		
		T1MF_Triangular upperLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper low NormFwd_Packet_Length_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower low NormFwd_Packet_Length_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_Packet_Length_Mean", upperLowNormFwdPacketLengthMeanMF, lowerLowNormFwdPacketLengthMeanMF);

		T1MF_Triangular  upperReasonableNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper reasonable NormFwd_Packet_Length_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower reasonable NormFwd_Packet_Length_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFwd_Packet_Length_Mean", upperReasonableNormFwdPacketLengthMeanMF, lowerReasonableNormFwdPacketLengthMeanMF);

		T1MF_Triangular upperHighNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper high NormFwd_Packet_Length_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower high NormFwd_Packet_Length_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_Packet_Length_Mean", upperHighNormFwdPacketLengthMeanMF, lowerHighNormFwdPacketLengthMeanMF);
		

		// NormFwd_Packet_Length_Std input
		T1MF_Triangular upperLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper low NormFwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for lower low NormFwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_Packet_Length_Std", upperLowNormFwdPacketLengthStdMF, lowerLowNormFwdPacketLengthStdMF);

		T1MF_Triangular  upperReasonableNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper reasonable NormFwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower reasonable NormFwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFwd_Packet_Length_Std", upperReasonableNormFwdPacketLengthStdMF, lowerReasonableNormFwdPacketLengthStdMF);

		T1MF_Triangular upperHighNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for upper high NormFwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdPacketLengthStdMF = new T1MF_Triangular("MF for lower high NormFwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_Packet_Length_Std", upperHighNormFwdPacketLengthStdMF, lowerHighNormFwdPacketLengthStdMF);

		
		//NormBwd_Packet_Length_Mean input 
		T1MF_Triangular upperLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper low NormFwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower low NormFwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_Packet_Length_Std", upperLowNormBwdPacketLengthMeanMF, lowerLowNormBwdPacketLengthMeanMF);

		T1MF_Triangular  upperReasonableNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper reasonable NormFwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdPacketLengthMeanMF  = new T1MF_Triangular("MF for lower reasonable NormFwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFwd_Packet_Length_Std", upperReasonableNormBwdPacketLengthMeanMF, lowerReasonableNormBwdPacketLengthMeanMF);

		T1MF_Triangular upperHighNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for upper high NormFwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdPacketLengthMeanMF = new T1MF_Triangular("MF for lower high NormFwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_Packet_Length_Std", upperHighNormBwdPacketLengthMeanMF, lowerHighNormBwdPacketLengthMeanMF);

		//NormBwd_Packet_Length_Std input 
		T1MF_Triangular upperLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper low NormBwd_Packet_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for lower low NormBwd_Packet_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for low NormBwd_Packet_Length_Std", upperLowNormBwdPacketLengthStdMF, lowerLowNormBwdPacketLengthStdMF);

		T1MF_Triangular  upperReasonableNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper reasonable NormBwd_Packet_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdPacketLengthStdMF  = new T1MF_Triangular("MF for lower reasonable NormBwd_Packet_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormBwd_Packet_Length_Std", upperReasonableNormBwdPacketLengthStdMF, lowerReasonableNormBwdPacketLengthStdMF);

		T1MF_Triangular upperHighNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for upper high NormBwd_Packet_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdPacketLengthStdMF = new T1MF_Triangular("MF for lower high NormBwd_Packet_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormBwd_Packet_Length_Std", upperHighNormBwdPacketLengthStdMF, lowerHighNormBwdPacketLengthStdMF);
		
		
		//NormFlow_IAT_Mean input NormFlowIATMean
		T1MF_Triangular upperLowNormFlowIATMeanMF = new T1MF_Triangular("MF for upper low NormFlow_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFlowIATMeanMF = new T1MF_Triangular("MF for lower low NormFlow_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFlow_IAT_Mean", upperLowNormFlowIATMeanMF, lowerLowNormFlowIATMeanMF);

		T1MF_Triangular  upperReasonableNormFlowIATMeanMF = new T1MF_Triangular("MF for upper reasonable NormFlow_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFlowIATMeanMF  = new T1MF_Triangular("MF for lower reasonable NormFlow_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFlow_IAT_Mean", upperReasonableNormFlowIATMeanMF, lowerReasonableNormFlowIATMeanMF);

		T1MF_Triangular upperHighNormFlowIATMeanMF = new T1MF_Triangular("MF for upper high NormFlow_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFlowIATMeanMF = new T1MF_Triangular("MF for lower high NormFlow_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFlowIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFlow_IAT_Mean", upperHighNormFlowIATMeanMF, lowerHighNormFlowIATMeanMF);

		
		//NormFlow_IAT_Std input NormFlowIATStd
		T1MF_Triangular upperLowNormFlowIATStdMF = new T1MF_Triangular("MF for upper low NormFlow_IAT_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFlowIATStdMF = new T1MF_Triangular("MF for lower low NormFlow_IAT_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFlow_IAT_Std", upperLowNormFlowIATStdMF, lowerLowNormFlowIATStdMF);

		T1MF_Triangular  upperReasonableNormFlowIATStdMF = new T1MF_Triangular("MF for upper reasonable NormFlow_IAT_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFlowIATStdMF  = new T1MF_Triangular("MF for lower reasonable NormFlow_IAT_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFlow_IAT_Std", upperReasonableNormFlowIATStdMF, lowerReasonableNormFlowIATStdMF);

		T1MF_Triangular upperHighNormFlowIATStdMF = new T1MF_Triangular("MF for upper high NormFlow_IAT_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFlowIATStdMF = new T1MF_Triangular("MF for lower high NormFlow_IAT_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFlowIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFlow_IAT_Std", upperHighNormFlowIATStdMF, lowerHighNormFlowIATStdMF);

		
		//NormFwd_IAT_Mean input NormFwdIATMean
		T1MF_Triangular upperLowNormFwdIATMeanMF = new T1MF_Triangular("MF for upper low NormFwd_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdIATMeanMF = new T1MF_Triangular("MF for lower low NormFwd_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_IAT_Mean", upperLowNormFwdIATMeanMF, lowerLowNormFwdIATMeanMF);

		T1MF_Triangular  upperReasonableNormFwdIATMeanMF = new T1MF_Triangular("MF for upper reasonable NormFwd_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdIATMeanMF  = new T1MF_Triangular("MF for lower reasonable NormFwd_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFwd_IAT_Mean", upperReasonableNormFwdIATMeanMF, lowerReasonableNormFwdIATMeanMF);

		T1MF_Triangular upperHighNormFwdIATMeanMF = new T1MF_Triangular("MF for upper high NormFwd_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdIATMeanMF = new T1MF_Triangular("MF for lower high NormFwd_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_IAT_Mean", upperHighNormFwdIATMeanMF, lowerHighNormFwdIATMeanMF);
		
		// NormFwd_IAT_Std input  
		T1MF_Triangular upperLowNormFwdIATStdMF = new T1MF_Triangular("MF for upper low NormFwd_IAT_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormFwdIATStdMF = new T1MF_Triangular("MF for lower low NormFwd_IAT_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for low NormFwd_IAT_Std", upperLowNormFwdIATStdMF, lowerLowNormFwdIATStdMF);

		T1MF_Triangular  upperReasonableNormFwdIATStdMF = new T1MF_Triangular("MF for upper reasonable NormFwd_IAT_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormFwdIATStdMF  = new T1MF_Triangular("MF for lower reasonable NormFwd_IAT_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormFwd_IAT_Std", upperReasonableNormFwdIATStdMF, lowerReasonableNormFwdIATStdMF);

		T1MF_Triangular upperHighNormFwdIATStdMF = new T1MF_Triangular("MF for upper high NormFwd_IAT_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormFwdIATStdMF = new T1MF_Triangular("MF for lower high NormFwd_IAT_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormFwdIATStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormFwd_IAT_Std", upperHighNormFwdIATStdMF, lowerHighNormFwdIATStdMF);

		// NormBwd_IAT_Mean input 
		T1MF_Triangular upperLowNormBwdIATMeanMF = new T1MF_Triangular("MF for upper low NormBwd_IAT_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormBwdIATMeanMF = new T1MF_Triangular("MF for lower low NormBwd_IAT_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormBwd_IAT_Mean", upperLowNormBwdIATMeanMF, lowerLowNormBwdIATMeanMF);

		T1MF_Triangular  upperReasonableNormBwdIATMeanMF = new T1MF_Triangular("MF for upper reasonable NormBwd_IAT_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormBwdIATMeanMF  = new T1MF_Triangular("MF for lower reasonable NormBwd_IAT_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormBwd_IAT_Mean", upperReasonableNormBwdIATMeanMF, lowerReasonableNormBwdIATMeanMF);

		T1MF_Triangular upperHighNormBwdIATMeanMF = new T1MF_Triangular("MF for upper high NormBwd_IAT_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormBwdIATMeanMF = new T1MF_Triangular("MF for lower high NormBwd_IAT_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormBwdIATMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormBwd_IAT_Mean", upperHighNormBwdIATMeanMF, lowerHighNormBwdIATMeanMF);

		//NormPacket_Length_Mean input
		T1MF_Triangular upperLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper low NormPacket_Length_Mean", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormPacketLengthMeanMF = new T1MF_Triangular("MF for lower low NormPacket_Length_Mean", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for low NormPacket_Length_Mean", upperLowNormPacketLengthMeanMF, lowerLowNormPacketLengthMeanMF);

		T1MF_Triangular  upperReasonableNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper reasonable NormPacket_Length_Mean", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormPacketLengthMeanMF  = new T1MF_Triangular("MF for lower reasonable NormPacket_Length_Mean", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormPacket_Length_Mean", upperReasonableNormPacketLengthMeanMF, lowerReasonableNormPacketLengthMeanMF);

		T1MF_Triangular upperHighNormPacketLengthMeanMF = new T1MF_Triangular("MF for upper high NormPacket_Length_Mean", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormPacketLengthMeanMF = new T1MF_Triangular("MF for lower high NormPacket_Length_Mean", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormPacketLengthMeanT2MF = new IntervalT2MF_Triangular("T2 MF for high NormPacket_Length_Mean", upperHighNormPacketLengthMeanMF, lowerHighNormPacketLengthMeanMF);
		
		
		// NormPacket_Length_Std input 
		T1MF_Triangular upperLowNormPacketLengthStdMF = new T1MF_Triangular("MF for upper low NormPacket_Length_Std", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowNormPacketLengthStdMF = new T1MF_Triangular("MF for lower low NormPacket_Length_Std", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for low NormPacket_Length_Std", upperLowNormPacketLengthStdMF, lowerLowNormPacketLengthStdMF);

		T1MF_Triangular  upperReasonableNormPacketLengthStdMF = new T1MF_Triangular("MF for upper reasonable NormPacket_Length_Std", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerReasonableNormPacketLengthStdMF  = new T1MF_Triangular("MF for lower reasonable NormPacket_Length_Std", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular reasonableNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable NormPacket_Length_Std", upperReasonableNormPacketLengthStdMF, lowerReasonableNormPacketLengthStdMF);

		T1MF_Triangular upperHighNormPacketLengthStdMF = new T1MF_Triangular("MF for upper high NormPacket_Length_Std", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighNormPacketLengthStdMF = new T1MF_Triangular("MF for lower high NormPacket_Length_Std", startLowerHighLimit, peakLowerHighLimit, endLowerHighLimit);
		IntervalT2MF_Triangular  highNormPacketLengthStdT2MF = new IntervalT2MF_Triangular("T2 MF for high NormPacket_Length_Std", upperHighNormPacketLengthStdMF, lowerHighNormPacketLengthStdMF);


		// Video output
		T1MF_Triangular upperLowVideoMF = new T1MF_Triangular("MF for upper low video", startUpperLowLimit, peakUpperLowLimit, endUpperLowLimit);
		T1MF_Triangular lowerLowVideoMF = new T1MF_Triangular("MF for lower low video", startLowerLowLimit, peakLowerLowLimit, endLowerLowLimit);
		IntervalT2MF_Triangular lowVideoT2MF = new IntervalT2MF_Triangular("T2 MF for low video", upperLowVideoMF, lowerLowVideoMF);

		T1MF_Triangular  upperAverageVideoMF = new T1MF_Triangular("MF for upper reasonable video", startUpperReasonableLimit, peakUpperReasonableLimit, endUpperReasonableLimit);
		T1MF_Triangular lowerAverageVideoMF  = new T1MF_Triangular("MF for lower reasonable video", startLowerReasonableLimit, peakLowerReasonableLimit, endLowerReasonableLimit);
		IntervalT2MF_Triangular averageVideoT2MF = new IntervalT2MF_Triangular("T2 MF for reasonable video", upperAverageVideoMF, lowerAverageVideoMF);

		T1MF_Triangular upperHighVideoMF = new T1MF_Triangular("MF for upper high video", startUpperHighLimit, peakUpperHighLimit, endUpperHighLimit);
		T1MF_Triangular lowerHighVideoMF = new T1MF_Triangular("MF for lower high video", startLowerHighLimit, peakLowerHighLimit, endUpperHighLimit);
		IntervalT2MF_Triangular  highVideoT2MF = new IntervalT2MF_Triangular("T2 MF for high video", upperHighNormFwdPacketLengthStdMF, lowerHighNormFwdPacketLengthStdMF);

		
		

		System.out.println("Membership functions setted...");
		
		// Set up the antecedents and consequents - note how the inputs are associated...

		// NormFwd_Packet_Length_Mean
		IT2_Antecedent lowNormFwd_Packet_Length_Mean = new IT2_Antecedent("Low NormFwd_Packet_Length_Mean", lowNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent reasonableNormFwd_Packet_Length_Mean = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Mean", reasonableNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		IT2_Antecedent highNormFwd_Packet_Length_Mean = new IT2_Antecedent("High NormFwd_Packet_Length_Mean", highNormFwdPacketLengthMeanT2MF, normFwdPacketLengthMean);
		
		// NormFwd_Packet_Length_Std antecedent
		 IT2_Antecedent lowNormFwd_Packet_Length_Std = new IT2_Antecedent("Low NormFwd_Packet_Length_Std", lowNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent reasonableNormFwd_Packet_Length_Std = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Std", reasonableNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 IT2_Antecedent highNormFwd_Packet_Length_Std = new IT2_Antecedent("High NormFwd_Packet_Length_Std", highNormFwdPacketLengthStdT2MF, normFwdPacketLengthStd);
		 
		// NormBwd_Packet_Length_Mean antecedent
		 IT2_Antecedent lowNormBwd_Packet_Length_Mean = new IT2_Antecedent("Low NormFwd_Packet_Length_Std", lowNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent reasonableNormBwd_Packet_Length_Mean = new IT2_Antecedent("Reasonable NormFwd_Packet_Length_Std", reasonableNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 IT2_Antecedent highNormBwd_Packet_Length_Mean = new IT2_Antecedent("High NormFwd_Packet_Length_Std", highNormBwdPacketLengthMeanT2MF, normBwdPacketLengthMean);
		 
		// NormBwd_Packet_Length_Std  antecedent
		 IT2_Antecedent lowNormBwd_Packet_Length_Std = new IT2_Antecedent("Low NormBwd_Packet_Length_Std ", lowNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent reasonableNormBwd_Packet_Length_Std = new IT2_Antecedent("Reasonable NormBwd_Packet_Length_Std ", reasonableNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 IT2_Antecedent highNormBwd_Packet_Length_Std = new IT2_Antecedent("High NormBwd_Packet_Length_Std ", highNormBwdPacketLengthStdT2MF, normBwdPacketLengthStd);
		 
		// NormFlow_IAT_Mean antecedent
		 IT2_Antecedent lowNormFlow_IAT_Mean = new IT2_Antecedent("Low NormFlow_IAT_Mean ", lowNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent reasonableNormFlow_IAT_Mean = new IT2_Antecedent("Reasonable NormFlow_IAT_Mean ", reasonableNormFlowIATMeanT2MF, normFlowIATMean);
		 IT2_Antecedent highNormFlow_IAT_Mean = new IT2_Antecedent("High NormFlow_IAT_Mean ", highNormFlowIATMeanT2MF, normFlowIATMean);
		 
		// NormFlow_IAT_Std antecedent 
		 IT2_Antecedent lowNormFlow_IAT_Std = new IT2_Antecedent("Low NormFlow_IAT_Std ", lowNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent reasonableNormFlow_IAT_Std = new IT2_Antecedent("Reasonable NormFlow_IAT_Std ", reasonableNormFlowIATStdT2MF, normFlowIATStd);
		 IT2_Antecedent highNormFlow_IAT_Std = new IT2_Antecedent("High NormFlow_IAT_Std ", highNormFlowIATStdT2MF, normFlowIATStd);

        // NormFwd_IAT_Mean input antecedent
		 IT2_Antecedent lowNormFwd_IAT_Mean = new IT2_Antecedent("Low NormFwd_IAT_Mean ", lowNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent reasonableNormFwd_IAT_Mean = new IT2_Antecedent("Reasonable NormFwd_IAT_Mean ", reasonableNormFwdIATMeanT2MF, normFwdIATMean);
		 IT2_Antecedent highNormFwd_IAT_Mean = new IT2_Antecedent("High NormFwd_IAT_Mean ", highNormFwdIATMeanT2MF, normFwdIATMean);
		
		// NormFwd_IAT_Std antecedent 
		 IT2_Antecedent lowNormFwd_IAT_Std = new IT2_Antecedent("Low NormFwd_IAT_Std ", lowNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent reasonableNormFwd_IAT_Std = new IT2_Antecedent("Reasonable NormFwd_IAT_Std ", reasonableNormFwdIATStdT2MF, normFwdIATStd);
		 IT2_Antecedent highNormFwd_IAT_Std = new IT2_Antecedent("High NormFwd_IAT_Std ", highNormFwdIATStdT2MF, normFwdIATStd);
		 
	   // NormBwd_IAT_Mean antecedent 
		 IT2_Antecedent lowNormBwd_IAT_Mean = new IT2_Antecedent("Low NormBwd_IAT_Mean ", lowNormFwdIATStdT2MF, normBwdIATMean);
		 IT2_Antecedent reasonableNormBwd_IAT_Mean = new IT2_Antecedent("Reasonable NormBwd_IAT_Mean ", reasonableNormBwdIATMeanT2MF, normBwdIATMean);
		 IT2_Antecedent highNormBwd_IAT_Mean = new IT2_Antecedent("High NormBwd_IAT_Mean ", highNormBwdIATMeanT2MF, normBwdIATMean);	
		 
		//NormPacket_Length_Mean antecedent
		 IT2_Antecedent lowNormPacket_Length_Mean = new IT2_Antecedent("Low NormPacket_Length_Mean ", lowNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent reasonableNormPacket_Length_Mean = new IT2_Antecedent("Reasonable NormPacket_Length_Mean ", reasonableNormPacketLengthMeanT2MF, normPacketLengthMean);
		 IT2_Antecedent highNormPacket_Length_Mean = new IT2_Antecedent("High NormPacket_Length_Mean ", highNormPacketLengthMeanT2MF, normPacketLengthMean);	


		// NormPacket_Length_Std antecedent
		 IT2_Antecedent lowNormPacket_Length_Std = new IT2_Antecedent("Low NormPacket_Length_Mean ", lowNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent reasonableNormPacket_Length_Std = new IT2_Antecedent("Reasonable NormPacket_Length_Mean ", reasonableNormPacketLengthStdT2MF, normPacketLengthStd);
		 IT2_Antecedent highNormPacket_Length_Std = new IT2_Antecedent("High NormPacket_Length_Mean ", highNormPacketLengthStdT2MF, normPacketLengthStd);	



         // Video consequent
		 IT2_Consequent lowVideo = new IT2_Consequent("Low Video", lowVideoT2MF, video);
		 IT2_Consequent averageVideo = new IT2_Consequent("Average Video", averageVideoT2MF, video);
		 IT2_Consequent highVideo = new IT2_Consequent("High Video", highVideoT2MF, video);

		System.out.println("Antecedents and consequents setted...");
		
		// Set up the rulebase and add rules 
		//https://github.com/emmonks/FuzzyNetClass/blob/main/Juzzy/regras_juzzy_video_26112022.txt
		rulebase = new IT2_Rulebase(519);
		// rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean, lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,reasonableNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,reasonableNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,reasonableNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,lowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormPacket_Length_Mean,lowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormPacket_Length_Mean,lowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean,highNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormBwd_IAT_Mean,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean,reasonableNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,highNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Mean,lowNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean,reasonableNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormFlow_IAT_Mean,highNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,reasonableNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,reasonableNormFlow_IAT_Mean,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,lowNormFlow_IAT_Mean,highNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean,highNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,reasonableNormBwd_Packet_Length_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,lowNormBwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_IAT_Mean,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormBwd_Packet_Length_Std,highNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormPacket_Length_Mean,lowNormFlow_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_IAT_Mean,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormBwd_IAT_Mean,reasonableNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean,highNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_IAT_Mean,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_IAT_Mean,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_IAT_Mean,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_IAT_Mean,reasonableNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Std,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormBwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,highNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std,reasonableNormFlow_IAT_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,lowNormFlow_IAT_Std,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Mean,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,highNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,lowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,lowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormBwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFlow_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,lowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_IAT_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,lowNormFwd_IAT_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,lowNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std,reasonableNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean,reasonableNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_IAT_Mean,reasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,highNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_Packet_Length_Mean,highNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormBwd_IAT_Mean,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormBwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,highNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std,highNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,reasonableNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,highNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_IAT_Mean,highNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Std,reasonableNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormBwd_IAT_Mean,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Mean,lowNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormBwd_Packet_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,highNormBwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormPacket_Length_Std,lowNormFlow_IAT_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean,reasonableNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormFwd_Packet_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,highNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormFwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,highNormPacket_Length_Mean,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormBwd_Packet_Length_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormPacket_Length_Std,reasonableNormFwd_Packet_Length_Std,lowNormFwd_IAT_Std,highNormPacket_Length_Mean },highVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std,highNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormBwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,reasonableNormPacket_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormBwd_Packet_Length_Std,lowNormFwd_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormPacket_Length_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,highNormFwd_IAT_Mean,lowNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,reasonableNormFwd_IAT_Std,reasonableNormBwd_Packet_Length_Mean,reasonableNormFlow_IAT_Mean,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,reasonableNormBwd_Packet_Length_Mean,lowNormFwd_IAT_Std,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,highNormBwd_Packet_Length_Std,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,lowNormFwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,highNormPacket_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormFlow_IAT_Std,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,lowNormFwd_IAT_Std,lowNormBwd_Packet_Length_Mean,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,lowNormFlow_IAT_Std,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormFwd_Packet_Length_Std,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,reasonableNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFlow_IAT_Std,lowNormFwd_Packet_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_Packet_Length_Mean,lowNormFwd_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean,lowNormFwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFlow_IAT_Std,lowNormFwd_IAT_Std,reasonableNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,reasonableNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,highNormFwd_IAT_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_IAT_Mean,reasonableNormPacket_Length_Mean,highNormPacket_Length_Std,reasonableNormBwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormFwd_IAT_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Std,lowNormFlow_IAT_Std,highNormFwd_IAT_Mean,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormFwd_IAT_Mean,highNormPacket_Length_Std,highNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_Packet_Length_Mean,highNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,reasonableNormPacket_Length_Mean,highNormFwd_IAT_Mean,highNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFlow_IAT_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFlow_IAT_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,reasonableNormFlow_IAT_Std,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormPacket_Length_Std,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Mean,lowNormPacket_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_Packet_Length_Mean,lowNormFwd_Packet_Length_Mean,lowNormPacket_Length_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormFlow_IAT_Mean,lowNormFlow_IAT_Std },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Std,reasonableNormBwd_IAT_Mean,lowNormFwd_IAT_Std,reasonableNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFlow_IAT_Std,lowNormFlow_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormBwd_IAT_Mean,lowNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,lowNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,lowNormFwd_IAT_Std,lowNormBwd_IAT_Mean,lowNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFwd_IAT_Mean,lowNormFlow_IAT_Std,lowNormBwd_IAT_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormFwd_Packet_Length_Std,reasonableNormBwd_Packet_Length_Mean,lowNormBwd_Packet_Length_Mean },lowVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ reasonableNormBwd_IAT_Mean,highNormBwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_IAT_Mean,highNormBwd_Packet_Length_Std,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormPacket_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_IAT_Mean,highNormBwd_Packet_Length_Std,lowNormPacket_Length_Mean,highNormPacket_Length_Std,highNormFwd_Packet_Length_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormBwd_IAT_Mean,highNormBwd_Packet_Length_Std,highNormFlow_IAT_Std,highNormPacket_Length_Std,lowNormPacket_Length_Mean,lowNormBwd_Packet_Length_Mean },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ lowNormFlow_IAT_Mean,highNormBwd_Packet_Length_Std,lowNormFwd_Packet_Length_Std,lowNormBwd_Packet_Length_Mean,highNormPacket_Length_Std,reasonableNormFlow_IAT_Std },averageVideo));
		rulebase.addRule(new IT2_Rule(new IT2_Antecedent[]{ highNormFwd_IAT_Mean,highNormBwd_Packet_Length_Std,highNormPacket_Length_Std,reasonableNormBwd_Packet_Length_Mean,highNormBwd_Packet_Length_Mean },averageVideo));		
		System.out.println("Rulebases setted...");

		/*
		normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd, normFlowIATMean, normFlowIATStd,
		normFwdIATMean, normFwdIATStd, normBwdIATMean, normPacketLengthMean, normPacketLengthStd
		*/
		//getClassification(5.5, 3.6, 5.2, 6.0, 3.0, 5.9, 4.3, 3.2, 2.1, 6.8, 9.4);
		

		//inicio aqui leitura e gravação em arquivo
		
		//String fileName = "final_clean.csv"; 
		String fileName = "dataset_25092022_D.csv";
		System.out.println("Reading Network flows dataset...");
		File dataset = new File("data" + File.separator + fileName);
		String line = new String();
		String[] data = new String[12];
		Scanner lineScan = new Scanner(dataset, "UTF-8");
		lineScan.nextLine();    
		
	    //Creating the output file
		
		int posPonto = fileName.indexOf(".");
		String outputFileName = fileName.substring(0, posPonto)+"_output.csv";
		
		
	    //String outputFileName = fileName + "output-" + java.time.LocalDateTime.now() + ".csv";
	    FileOutputStream outputFLSFile = new FileOutputStream("data/" + outputFileName);
	    
	    System.out.println("Starting FLS...");
	    

		StringBuffer outputFLS = new StringBuffer();
		outputFLS.append("Sequencial, NormFwd_Packet_Length_Mean, NormFwd_Packet_Length_Std, NormBwd_Packet_Length_Mean, NormBwd_Packet_Length_Std, "
				+ "NormFlow_IAT_Mean, NormFlow_IAT_Std, NormFwd_IAT_Mean, NormFwd_IAT_Std, NormBwd_IAT_Mean, NormPacket_Length_Mean, "
				+ "NormPacket_Length_Std, Label, xPonctual, xInf, xSup, lowerLowVideo, upperLowVideo, lowerAverageVideo, upperAverageVideo,"
				+ " lowerHighVideo,  upperHighVideo").append("\n");
		
		
		outputFLSFile.write(outputFLS.toString().getBytes());
		
		
		
		int x=0;
		while(lineScan.hasNext()) {
			x++;
			line = lineScan.nextLine();
			
			//split the dataset line by semicolon
			data = line.split(",");
			
			outputFLS = new StringBuffer();
			
			// normFwdPacketLengthMean, normFwdPacketLengthStd, normBwdPacketLengthMean, normBwdPacketLengthStd, normFlowIATMean, normFlowIATStd,
			// normFwdIATMean, normFwdIATStd, normBwdIATMean, normPacketLengthMean, normPacketLengthStd
			Double point = getClassification(Double.valueOf(data[0]), Double.valueOf(data[1]), Double.valueOf(data[2]), Double.valueOf(data[3]),
											 Double.valueOf(data[4]), Double.valueOf(data[5]), Double.valueOf(data[6]), Double.valueOf(data[7]), 
											 Double.valueOf(data[8]), Double.valueOf(data[9]), Double.valueOf(data[10]));
			
			
			double  upperLowVideo = lowVideoT2MF.getUpperBound(point);
			double  lowerLowVideo = lowVideoT2MF.getLowerBound(point);
			
			double  upperAverageVideo  = averageVideoT2MF.getUpperBound(point);
			double  lowerAverageVideo  = averageVideoT2MF.getLowerBound(point);
			
			double upperHighVideo = highVideoT2MF.getUpperBound(point);
			double lowerHighVideo = highVideoT2MF.getLowerBound(point);
			
			double avgLowVideo = (lowerLowVideo + lowerLowVideo)/2;
			double avgAverageVideo = (lowerAverageVideo + upperHighVideo)/2;
			double avgHighVideo = (lowerHighVideo + upperHighVideo)/2;
			
			
			// Write the FLS output of network classification
			outputFLS.append(x).append(", ") // Sequencial
			.append(data[0]).append(", ") // NormFwd_Packet_Length_Mean
			.append(data[1]).append(", ") // NormFwd_Packet_Length_Std
			.append(data[2]).append(", ") // NormBwd_Packet_Length_Mean
			.append(data[3]).append(", ") // NormBwd_Packet_Length_Std
			.append(data[4]).append(", ") // NormFlow_IAT_Mean
			.append(data[5]).append(", ") // NormFlow_IAT_Std
			.append(data[6]).append(", ") // NormFwd_IAT_Mean
			.append(data[7]).append(", ") // NormFwd_IAT_Std
			.append(data[8]).append(", ") // NormBwd_IAT_Mean
			.append(data[9]).append(", ") // NormPacket_Length_Mean
			.append(data[10]).append(", ") // NormPacket_Length_Std
			.append(data[11]).append(", ") // Label
			.append(point).append(", ")
			.append(this.OutputXValue).append(", ")
			.append(this.OutputYValue).append(", ")
			.append(lowerLowVideo).append(", ")
			.append(upperLowVideo).append(", ")
			.append(lowerAverageVideo).append(", ")
			.append(upperAverageVideo).append(", ")
			.append(lowerHighVideo).append(", ")
			.append(upperHighVideo).append(", ")
			.append("\n");
			
			outputFLSFile.write(outputFLS.toString().getBytes());
			
		}
		outputFLSFile.close();
		lineScan.close();
		
		System.out.println("Output file generated!");
		
		//fim da leitura e processamento do dataset
		
		
		
		// plot some sets, discretizing each input into 100 steps.
		plotMFs("normFwdPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface [] { lowNormFwdPacketLengthMeanT2MF, reasonableNormFwdPacketLengthMeanT2MF, highNormFwdPacketLengthMeanT2MF },
				normFwdPacketLengthMean.getDomain(), 100);
		
		plotMFs("normFwdPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { lowNormFwdPacketLengthStdT2MF, reasonableNormFwdPacketLengthStdT2MF, highNormFwdPacketLengthStdT2MF },
				normFwdPacketLengthStd.getDomain(), 100);
		
		plotMFs("normBwdPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface[] { lowNormBwdPacketLengthMeanT2MF, reasonableNormBwdPacketLengthMeanT2MF, highNormBwdPacketLengthMeanT2MF },
				normBwdPacketLengthMean.getDomain(), 100);
		
		plotMFs("normBwdPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { lowNormBwdPacketLengthStdT2MF, reasonableNormBwdPacketLengthStdT2MF, highNormBwdPacketLengthStdT2MF },
				normBwdPacketLengthStd.getDomain(), 100);
		
		plotMFs("normFlowIATMean Membership Functions",
				new IntervalT2MF_Interface[] { lowNormFlowIATMeanT2MF, reasonableNormFlowIATMeanT2MF, highNormFlowIATMeanT2MF },
				normFlowIATMean.getDomain(), 100);
		
		plotMFs("normFlowIATStd Membership Functions",
				new IntervalT2MF_Interface[] { lowNormFlowIATStdT2MF, reasonableNormFlowIATStdT2MF, highNormFlowIATStdT2MF },
				normFlowIATStd.getDomain(), 100);
		
		plotMFs("normFwdIATMean Membership Functions",
				new IntervalT2MF_Interface[] { lowNormFwdIATMeanT2MF, reasonableNormFwdIATMeanT2MF, highNormFwdIATMeanT2MF },
				normFwdIATMean.getDomain(), 100);

		plotMFs("normFwdIATStd Membership Functions",
				new IntervalT2MF_Interface[] { lowNormFwdIATStdT2MF, reasonableNormFwdIATStdT2MF, highNormFwdIATStdT2MF },
				normFwdIATStd.getDomain(), 100);
		
		plotMFs("normBwdIATMean Membership Functions",
				new IntervalT2MF_Interface[] { lowNormBwdIATMeanT2MF, reasonableNormBwdIATMeanT2MF, highNormBwdIATMeanT2MF },
				normBwdIATMean.getDomain(), 100);
		
		plotMFs("normPacketLengthMean Membership Functions",
				new IntervalT2MF_Interface[] { lowNormPacketLengthMeanT2MF, reasonableNormPacketLengthMeanT2MF, highNormPacketLengthMeanT2MF },
				normPacketLengthMean.getDomain(), 100);
		
		plotMFs("normPacketLengthStd Membership Functions",
				new IntervalT2MF_Interface[] { lowNormPacketLengthStdT2MF, reasonableNormPacketLengthStdT2MF, highNormPacketLengthStdT2MF },
				normPacketLengthStd.getDomain(), 100);

		
		plotMFs("Video Membership Functions",
				new IntervalT2MF_Interface[] { lowVideoT2MF, averageVideoT2MF, highVideoT2MF },
				video.getDomain(), 100);

		// plot control surface
		// do either height defuzzification (false) or centroid d. (true)
		plotControlSurface(true, 10, 10);

		// print out the rules
		System.out.println("\n" + rulebase);
		 
		 
	}

	/**
	 * Basic method that prints the output for a given set of inputs.
	 * 
	 * @param negativityMeasure
	 * @param positivityMeasure
	 * @throws IOException
	 */

	private Double getClassification(double normFwdPacketLengthMean, double normFwdPacketLengthStd, double normBwdPacketLengthMean, double normBwdPacketLengthStd,
			double normFlowIATMean, double normFlowIATStd, double normFwdIATMean, double normFwdIATStd, double normBwdIATMean, double normPacketLengthMean, double normPacketLengthStd) {
		// first, set the inputs
		this.normFwdPacketLengthMean.setInput(normFwdPacketLengthMean);
		this.normFwdPacketLengthStd.setInput(normFwdPacketLengthStd);
		this.normBwdPacketLengthMean.setInput(normBwdPacketLengthMean);
		this.normBwdPacketLengthStd.setInput(normBwdPacketLengthStd);
		this.normFlowIATMean.setInput(normFlowIATMean);
		this.normFlowIATStd.setInput(normFlowIATStd);
		this.normFwdIATMean.setInput(normFwdIATMean);
		this.normFwdIATStd.setInput(normFwdIATStd);
		this.normBwdIATMean.setInput(normBwdIATMean);
		this.normPacketLengthMean.setInput(normPacketLengthMean);
		this.normPacketLengthStd.setInput(normPacketLengthStd);
		
		// now execute the FLS and print output
//		System.out.println("The negativity measure was: " + negativity.getInput());
//		System.out.println("The positivity measure was: " + positivity.getInput());
//		System.out.println("Using height defuzzification " + rulebase.evaluate(0).get(classification));
//		System.out.println("Using centroid defuzzification " + rulebase.evaluate(1).get(classification));

		//this.OutputXValue = rulebase.evaluateGetCentroid(0)

		TreeMap<Output, Object[]> centroid = rulebase.evaluateGetCentroid(1);
    	Object[] centroidTip = centroid.get(video);
        Tuple centroidTipXValues = (Tuple)centroidTip[0];
				
        this.OutputXValue = centroidTipXValues.getLeft();
        this.OutputYValue = centroidTipXValues.getRight();
                
		//return rulebase.evaluate(1).get(classification);
		return centroidTipXValues.getAverage();
		
	}

	private void plotMFs(String name, IntervalT2MF_Interface[] sets, Tuple xAxisRange, int discretizationLevel) {
		JMathPlotter plotter = new JMathPlotter();
		for (int i = 0; i < sets.length; i++) {
			plotter.plotMF(sets[i].getName(), sets[i], discretizationLevel, null, false);
		}
		plotter.show(name);
	}

	private void plotControlSurface(boolean useCentroidDefuzzification, int input1Discs, int input2Discs) {
		double output;
		double[] x = new double[input1Discs];
		double[] y = new double[input2Discs];
		double[][] z = new double[y.length][x.length];
		double incrX, incrY;
		incrX = normFwdPacketLengthMean.getDomain().getSize() / (input1Discs - 1.0);
		incrY = normFwdPacketLengthStd.getDomain().getSize() / (input2Discs - 1.0);

		// first, get the values
		for (int currentX = 0; currentX < input1Discs; currentX++) {
			x[currentX] = currentX * incrX;
		}
		for (int currentY = 0; currentY < input2Discs; currentY++) {
			y[currentY] = currentY * incrY;
		}

		for (int currentX = 0; currentX < input1Discs; currentX++) {
			normFwdPacketLengthMean.setInput(x[currentX]);
			for (int currentY = 0; currentY < input2Discs; currentY++) {
				normFwdPacketLengthStd.setInput(y[currentY]);
				if (useCentroidDefuzzification)
					output = rulebase.evaluate(1).get(video);
				else
					output = rulebase.evaluate(0).get(video);
				z[currentY][currentX] = output;
			}
		}

		// now do the plotting
		JMathPlotter plotter = new JMathPlotter(17, 17, 14);
		plotter.plotControlSurface("Control Surface",
				new String[] { normFwdPacketLengthMean.getName(), normFwdPacketLengthStd.getName(), "Video" }, x, y, z,
				new Tuple(0.0, 1.0), true);
		plotter.show("Type-1 Fuzzy Logic System Control Surface for Sentiment Analysis");
	}

	
	/*
	public static void main(String args[]) throws IOException {
		new FuzzyClassifyNetworkTraficBackup();
	}
	
	*/
}