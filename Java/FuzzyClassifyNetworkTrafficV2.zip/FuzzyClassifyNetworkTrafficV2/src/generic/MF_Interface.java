package generic;

public interface MF_Interface {

	public String getName();
}
